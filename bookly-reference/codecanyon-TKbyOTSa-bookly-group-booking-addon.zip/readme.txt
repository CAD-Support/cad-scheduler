=== Bookly Group Booking Add-on ===

Thank you for purchasing Bookly Group Booking add-on.

Please read about the installation procedure and add-on features in the online documentation:

https://support.booking-wp-plugin.com/hc/en-us/articles/360000259594-Group-Booking-Add-on


Wish your business prosper with Bookly!

Bookly Team
Email: support@bookly.info