<?php
namespace BooklyMultiplyAppointments\Backend\Components\Divi\ProxyProviders;

use Bookly\Backend\Components\Divi\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormFields( array $fields )
    {
        $fields['hide_quantity'] = array(
            'label' => __( 'Hide quantity', 'bookly' ),
            'type' => 'yes_no_button',
            'options' => array(
                'off' => esc_html__( 'No', 'bookly' ),
                'on' => esc_html__( 'Yes', 'bookly' ),
            ),
            'default' => 'off',
            'toggle_slug' => 'main_content',
        );

        return $fields;
    }

    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormShortcode( array $shortcode, array $props )
    {
        list( $short_code, $hide ) = $shortcode;

        if ( isset( $props['hide_quantity'] ) && $props['hide_quantity'] === 'on' ) {
            $hide[] = 'quantity';
        }

        return array( $short_code, $hide );
    }
}
