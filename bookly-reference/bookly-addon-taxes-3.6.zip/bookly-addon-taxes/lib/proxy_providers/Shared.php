<?php
namespace BooklyTaxes\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;

class Shared extends BooklyLib\Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function preparePaymentDetails( $details )
    {
        $payment = $details->getPayment();
        $data = array(
            'tax_paid' => '0',
            'tax_in_price' => get_option( 'bookly_taxes_in_price' )
        );
        if ( $payment && ! in_array( $payment->getType(), array( BooklyLib\Entities\Payment::TYPE_LOCAL, BooklyLib\Entities\Payment::TYPE_FREE, BooklyLib\Entities\Payment::TYPE_WOOCOMMERCE ) ) ) {
            $data['tax_paid'] = (string) $details->getCartInfo()->getPayTax();
        }
        $details->setData( $data );

        return $details;
    }

    /**
     * @inheritDoc
     */
    public static function prepareTableColumns( $columns, $table )
    {
        if ( $table == BooklyLib\Utils\Tables::TAXES ) {
            $columns = array_merge( $columns, array(
                'id' => esc_html__( 'ID', 'bookly' ),
                'title' => esc_html__( 'Title', 'bookly' ),
                'rate' => esc_html__( 'Rate', 'bookly' ),
            ) );
        }

        return $columns;
    }

    /**
     * @inheritDoc
     */
    public static function prepareTableDefaultSettings( $columns, $table )
    {
        if ( $table == BooklyLib\Utils\Tables::TAXES ) {
            $columns = array_merge( $columns, array(
                'id' => false,
            ) );
        }

        return $columns;
    }
}