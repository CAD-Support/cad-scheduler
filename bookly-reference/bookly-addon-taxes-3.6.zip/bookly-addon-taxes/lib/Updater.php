<?php
namespace BooklyTaxes\Lib;

use Bookly\Lib as BooklyLib;

class Updater extends BooklyLib\Base\Updater
{
    public function update_3_4()
    {
        $new_pc_key = 'bookly_taxes_purchase_code';
        $old_pc_key = 'bookly_taxes_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_1_7()
    {
        $this->upgradeCharsetCollate( array(
            'bookly_taxes',
            'bookly_service_taxes',
        ) );
    }

    public function update_1_4()
    {
        $this->alterTables( array(
            'bookly_taxes' => array( 'ALTER TABLE `%s` CHANGE COLUMN `rate` `rate` DECIMAL(10,3) NOT NULL DEFAULT \'0.000\'' ),
        ) );
    }

    public function update_1_2()
    {
        /** @global \wpdb $wpdb */
        global $wpdb;

        // Rename tables.
        $tables = array(
            'service_taxes',
            'taxes',
        );
        $query = 'RENAME TABLE ';
        foreach ( $tables as $table ) {
            $query .= sprintf( '`%s` TO `%s`, ', $this->getTableName( 'ab_' . $table ), $this->getTableName( 'bookly_' . $table ) );
        }
        $query = substr( $query, 0, -2 );
        $wpdb->query( $query );

        delete_option( 'bookly_taxes_enabled' );
    }
}