<?php
namespace BooklyTaxes\Backend\Components\Dialogs\Tax;

use Bookly\Lib as BooklyLib;
use BooklyTaxes\Lib\Entities\Tax;

class EditAjax extends BooklyLib\Base\Ajax
{
    /**
     * Add new tax.
     */
    public static function saveTax()
    {
        $parameters = self::parameters();
        $tax = new Tax();
        if ( self::hasParameter( 'id' ) ) {
            $tax->load( self::parameter( 'id' ) );
        }
        $tax->setFields( $parameters )->save();

        wp_send_json_success( $tax->getFields() );
    }
}