<?php
namespace BooklyTaxes\Backend\Components\Dialogs\Service\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Service\Edit\Proxy;
use BooklyTaxes\Lib\Entities;

class Local extends Proxy\Taxes
{
    /**
     * @inheritDoc
     */
    public static function renderSubForm( array $service )
    {
        $taxes = Entities\Tax::query()->sortBy( 'title' )->fetchArray();
        $service_taxes = Entities\ServiceTax::query()->where( 'service_id', $service['id'] )->fetchCol( 'tax_id' );

        self::renderTemplate( 'sub_form', compact( 'service', 'taxes', 'service_taxes' ) );
    }
}