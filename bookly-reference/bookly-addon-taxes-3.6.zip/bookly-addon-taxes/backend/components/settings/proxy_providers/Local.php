<?php
namespace BooklyTaxes\Backend\Components\Settings\ProxyProviders;

use Bookly\Backend\Components\Settings\Proxy;

class Local extends Proxy\Taxes
{
    /**
     * @inheritDoc
     */
    public static function renderHelpMessage()
    {
        self::renderTemplate( 'help_block' );
    }
}