<?php
namespace BooklyTaxes\Backend\Modules\Settings\ProxyProviders;

use Bookly\Backend\Modules\Settings\Proxy;

class Local extends Proxy\Taxes
{
    /**
     * @inheritDoc
     */
    public static function renderPayments()
    {
        self::renderTemplate( 'taxes_in_price' );
    }
}