<?php
namespace BooklyTaxes\Backend\Modules\Services\ProxyProviders;

use Bookly\Backend\Modules\Services\Proxy;
use BooklyTaxes\Lib\Entities\ServiceTax;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function duplicateService( $source_id, $target_id )
    {
        foreach ( ServiceTax::query()->where( 'service_id', $source_id )->fetchArray() as $record ) {
            $new_record = new ServiceTax( $record );
            $new_record->setId( null )->setServiceId( $target_id )->save();
        }
    }
}