<?php
namespace BooklyTaxes\Backend\Modules\Notifications\ProxyProviders;

use Bookly\Backend\Modules\Notifications\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareNotificationCodes( array $codes, $type )
    {
        $codes['service']['service_tax'] = array( 'description' => __( 'Service tax amount', 'bookly' ), 'if' => true );
        $codes['service']['service_tax_rate'] = array( 'description' => __( 'Service tax rate', 'bookly' ), 'if' => true );
        $codes['service']['total_tax'] = array( 'description' => __( 'Total tax included in the appointment (summary for all items)', 'bookly' ), 'if' => true );
        $codes['service']['total_price_no_tax'] = array( 'description' => __( 'Total price without tax', 'bookly' ), 'if' => true );

        $codes['cart']['total_tax'] = array( 'description' => __( 'Total tax included in the appointment (summary for all items)', 'bookly' ), 'if' => true );
        $codes['cart']['total_price_no_tax'] = array( 'description' => __( 'Total price without tax', 'bookly' ), 'if' => true );

        $codes['series']['total_tax'] = array( 'description' => __( 'Total tax included in the appointment (summary for all items)', 'bookly' ), 'if' => true );
        $codes['series']['total_price_no_tax'] = array( 'description' => __( 'Total price without tax', 'bookly' ), 'if' => true );

        return $codes;
    }
}