<?php
namespace BooklyTaxes\Backend\Modules\Taxes;

use Bookly\Lib as BooklyLib;
use BooklyTaxes\Lib;

class Ajax extends BooklyLib\Base\Ajax
{
    /**
     * Get list of tax.
     */
    public static function getTaxes()
    {
        $taxes = Lib\Entities\Tax::query( 't' )
            ->select( 't.id, t.title, t.rate' )
            ->fetchArray();

        wp_send_json( array(
            'draw' => (int) self::parameter( 'draw' ),
            'recordsTotal' => count( $taxes ),
            'recordsFiltered' => count( $taxes ),
            'data' => $taxes,
        ) );
    }

    /**
     * Remove tax(s).
     */
    public static function deleteTaxes()
    {
        $taxes = array_map( 'intval', self::parameter( 'taxes', array() ) );
        Lib\Entities\Tax::query()->delete()->whereIn( 'id', $taxes )->execute();
        wp_send_json_success();
    }

}