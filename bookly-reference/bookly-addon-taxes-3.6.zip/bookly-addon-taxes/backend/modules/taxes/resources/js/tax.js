jQuery(function ($) {
    'use strict';

    const table = 'taxes';
    const $modal = $('#bookly-tax-modal');
    const $modalTitle = $('#bookly-tax-modal-title');
    const $taxTitle = $('#bookly-tax-title');
    const $taxRate = $('#bookly-tax-rate');
    const $saveButton = $('#bookly-tax-save');

    // id of the tax being edited; null => creating a new one.
    let editId = null;

    /**
     * Init columns.
     */
    let columns = [];

    $.each(BooklyTaxesL10n.datatables[table].settings.columns, function (column, show) {
        switch (column) {
            case 'rate':
                columns.push({
                    data: column,
                    class: 'bookly:text-right',
                    render: function (data) { return BooklyDatatables.escapeHtml(data); }
                });
                break;
            default:
                columns.push({ data: column, render: BooklyDatatables.escapeHtml() });
                break;
        }
        columns[columns.length - 1].title = BooklyTaxesL10n.datatables[table].titles[column] || column;
        columns[columns.length - 1].name = column;
        columns[columns.length - 1].show = show;
    });

    /**
     * Init datatable.
     */
    let bt = BooklyDatatables.showForm('bookly-' + table + '-datatables', {
        serverSide: false,
        ajax: {
            url: ajaxurl,
            method: 'POST',
            data: function (d) {
                return $.extend({
                    action: 'bookly_taxes_get_taxes',
                    csrf_token: BooklyL10nGlobal.csrf_token
                }, d);
            }
        },
        columns: columns,
        tableSettings: Object.assign({}, BooklyTaxesL10n.datatables[table], {
            l10n: Object.assign({}, BooklyTaxesL10n.datatables.l10n, { zeroRecords: BooklyTaxesL10n.zeroRecords })
        }),
        edit: function (row) {
            openModal(row);
        },
        checked: function () {
            return [{
                label: BooklyTaxesL10n.delete,
                icon: 'trash',
                variant: 'destructive',
                click: function (selected) { deleteTaxes(selected.map(function (r) { return r.id; })); }
            }];
        },
        searchFilter: {
            placeholder: BooklyTaxesL10n.search,
            name: 'filter[search]'
        },
        saveSettings: function (settings) {
            $.post(ajaxurl, Object.assign({
                action: 'bookly_update_table_settings',
                table: table,
                csrf_token: BooklyL10nGlobal.csrf_token
            }, settings));
        },
        topToolbar: [{
            id: 'bookly-new-tax',
            label: BooklyTaxesL10n.new_tax,
            icon: 'plus',
            variant: 'default',
            click: function () { openModal(null); }
        }]
    });

    /**
     * Open create/edit modal. row === null => new tax.
     */
    function openModal(row) {
        editId = row ? row.id : null;
        $modalTitle.html(row ? BooklyTaxesL10n.title.edit : BooklyTaxesL10n.title.new);
        $taxTitle.val(row ? row.title : '').removeClass('is-invalid');
        $taxRate.val(row ? row.rate : '').removeClass('is-invalid');
        $modal.booklyModal('show');
    }

    /**
     * Save tax.
     */
    $saveButton.on('click', function (e) {
        e.preventDefault();
        let $form = $(this).parents('form'),
            data = $form.serializeArray(),
            ladda = Ladda.create(this, { timeout: 2000 }),
            abort = false;

        $('input[required]', $form).each(function () {
            if ($(this).val() === '') {
                $(this).addClass('is-invalid');
                abort = true;
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        if (abort) {
            return false;
        }

        data.push({ name: 'action', value: 'bookly_taxes_save_tax' });
        if (editId) {
            data.push({ name: 'id', value: editId });
        }
        ladda.start();
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function (response) {
                ladda.stop();
                if (response.success) {
                    $modal.booklyModal('hide');
                    bt.reload();
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    /**
     * Delete the given taxes by ids.
     */
    function deleteTaxes(ids) {
        if (!confirm(BooklyTaxesL10n.are_you_sure)) {
            return;
        }
        bt.setLoading(true);
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bookly_taxes_delete_taxes',
                csrf_token: BooklyL10nGlobal.csrf_token,
                taxes: ids
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    bt.reload();
                } else {
                    bt.setLoading(false);
                    alert(response.data.message);
                }
            }
        });
    }
});
