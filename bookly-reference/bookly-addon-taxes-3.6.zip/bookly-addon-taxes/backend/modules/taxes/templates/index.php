<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\PageHeader\Renderer as PageHeaderRenderer;
use Bookly\Backend\Components as BooklyComponents;
use BooklyTaxes\Backend\Components;
?>
<div id="bookly-tbs" class="wrap bookly-css-root bookly-main-page-wrap">
    <?php PageHeaderRenderer::render( $self::pageSlug(), __( 'Taxes', 'bookly' ) ) ?>

    <div class="bookly:card">
        <div class="bookly:card-body">
            <div id="bookly-taxes-datatables"></div>
        </div>
    </div>

    <?php Components\Dialogs\Tax\Edit::render() ?>
</div>