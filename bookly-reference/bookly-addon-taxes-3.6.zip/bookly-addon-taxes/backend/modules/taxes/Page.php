<?php
namespace BooklyTaxes\Backend\Modules\Taxes;

use Bookly\Lib as BooklyLib;

class Page extends BooklyLib\Base\Component
{
    /**
     * Render page.
     */
    public static function render()
    {
        self::enqueueStyles( array(
            'alias' => array( 'bookly-backend-globals', ),
        ) );

        self::enqueueScripts( array(
            'module' => array(
                'js/tax.js' => array( 'bookly-backend-globals' ),
            ),
        ) );

        $datatables = BooklyLib\Utils\Tables::getSettings( BooklyLib\Utils\Tables::TAXES );

        wp_localize_script( 'bookly-tax.js', 'BooklyTaxesL10n', array(
            'edit' => __( 'Edit', 'bookly' ),
            'delete' => __( 'Delete', 'bookly' ) . '…',
            'new_tax' => __( 'New tax', 'bookly' ) . '…',
            'search' => __( 'Quick search by title', 'bookly' ) . '…',
            'title' => array(
                'new' => __( 'New tax', 'bookly' ),
                'edit' => __( 'Edit tax', 'bookly' ),
            ),
            'are_you_sure' => __( 'Are you sure?', 'bookly' ),
            'zeroRecords' => __( 'No taxes found.', 'bookly' ),
            'datatables' => $datatables,
        ) );

        self::renderTemplate( 'index' );
    }
}