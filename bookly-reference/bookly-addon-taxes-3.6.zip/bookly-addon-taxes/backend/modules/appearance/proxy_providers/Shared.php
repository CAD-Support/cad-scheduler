<?php
namespace BooklyTaxes\Backend\Modules\Appearance\ProxyProviders;

use Bookly\Backend\Modules\Appearance\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareCodes( array $codes )
    {
        return array_merge( $codes, array(
            'service_tax' => array( 'description' => __( 'Service tax amount', 'bookly' ), 'if' => true, 'flags' => array( 'step' => '>=5' ) ),
            'service_tax_rate' => array( 'description' => __( 'Service tax rate', 'bookly' ), 'if' => true, 'flags' => array( 'step' => '>=5' ) ),
            'total_tax' => array( 'description' => __( 'Total tax included in the appointment (summary for all items)', 'bookly' ), 'if' => true, 'flags' => array( 'step' => '>=5' ) ),
            'total_price_no_tax' => array( 'description' => __( 'Total price without tax', 'bookly' ), 'if' => true, 'flags' => array( 'step' => '>=5' ) ),
        ) );
    }
}