<?php
namespace BooklyStaffCabinet\Frontend\Modules\Appointments;

use Bookly\Lib as BooklyLib;

class Ajax extends BooklyLib\Base\Ajax
{
    /**
     * @inheritDoc
     */
    protected static function permissions()
    {
        return array(
            'getAppointments' => 'staff',
        );
    }

    /**
     * Get list of appointments.
     */
    public static function getAppointments()
    {
        $columns = BooklyLib\Utils\Tables::filterColumns( self::parameter( 'columns' ), BooklyLib\Utils\Tables::APPOINTMENTS );
        $order = self::parameter( 'order', array() );
        $filter = self::parameter( 'filter' );
        $limits = array(
            'length' => self::parameter( 'length' ),
            'start' => self::parameter( 'start' ),
        );
        /** @var BooklyLib\Entities\Staff $staff */
        $staff = BooklyLib\Entities\Staff::query()->where( 'wp_user_id', get_current_user_id() )->findOne();

        $filter['staff'] = 0;
        $display_tz = null;
        if ( $staff ) {
            $filter['staff'] = $staff->getId();
            $display_tz = $staff->getTimeZone();
        }

        $data = \Bookly\Backend\Modules\Appointments\Ajax::getAppointmentsTableData( $filter, $limits, $columns, $order, false, $display_tz );

        wp_send_json( array(
            'draw' => ( int ) self::parameter( 'draw' ),
            'recordsTotal' => $data['total'],
            'recordsFiltered' => $data['filtered'],
            'data' => $data['data'],
        ) );
    }
}