<?php
namespace BooklyLocations\Backend\Components\Divi\ProxyProviders;

use Bookly\Backend\Components\Divi\Proxy;
use Bookly\Lib\Config;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormFields( array $fields )
    {
        if ( ! Config::locationsActive() ) {
            return $fields;
        }

        $locations = array( 0 => __( 'Select location', 'bookly' ) );
        $casest = Config::getCaSeSt();
        foreach ( $casest['locations'] as $location ) {
            $locations[ $location['id'] ] = $location['name'];
        }

        return array(
            'location_id' => array(
                'label' => __( 'Location', 'bookly' ),
                'type' => 'select',
                'options' => $locations,
                'default' => '0',
                'toggle_slug' => 'main_content',
            ),
            'hide_locations' => array(
                'label' => __( 'Hide location', 'bookly' ),
                'type' => 'yes_no_button',
                'options' => array(
                    'off' => esc_html__( 'No', 'bookly' ),
                    'on' => esc_html__( 'Yes', 'bookly' ),
                ),
                'default' => 'off',
                'toggle_slug' => 'main_content',
            ),
        ) + $fields;
    }

    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormShortcode( array $shortcode, array $props )
    {
        if ( ! Config::locationsActive() ) {
            return $shortcode;
        }

        list( $short_code, $hide ) = $shortcode;

        if ( ! empty( $props['location_id'] ) && $props['location_id'] !== '0' ) {
            $short_code .= ' location_id="' . (int) $props['location_id'] . '"';
        }
        if ( isset( $props['hide_locations'] ) && $props['hide_locations'] === 'on' ) {
            $hide[] = 'locations';
        }

        return array( $short_code, $hide );
    }
}
