<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Settings\Inputs;
use Bookly\Backend\Components\Settings\Payments;
use Bookly\Backend\Components\Settings\Selects;
use Bookly\Backend\Components\Controls\Elements;
use Bookly\Lib\Utils\DateTime;
use Bookly\Lib\Plugin;
use Bookly\Lib\Cloud;
?>
<div class="card bookly-collapse-with-arrow" data-gateway="<?php echo esc_attr( $type ) ?>">
    <div class="card-header d-flex align-items-center">
        <?php Elements::renderReorder() ?>
        <a href="#bookly_pmt_stripe" class="ml-2" role="button" data-toggle="bookly-collapse">
            Stripe
        </a>
        <img class="ml-auto" src="<?php echo plugins_url( 'backend/modules/settings/resources/images/stripe.svg', Plugin::getMainFile() ) ?>" />
    </div>
    <div id="bookly_pmt_stripe" class="bookly-collapse bookly-show">
        <div class="card-body">
            <?php Selects::renderSingle( 'bookly_stripe_enabled', null, null, array(), array( 'data-expand' => '1' ) ) ?>
            <div class="bookly_stripe_enabled-expander">
                <div class="form-group">
                    <h4><?php esc_html_e( 'Instructions', 'bookly' ) ?></h4>
                    <ol>
                        <li><?php printf( __( 'Provide <b>Secret</b> and <b>Publishable</b> keys which are available in the <a href="%s" target="_blank">Dashboard</a>.', 'bookly' ), 'https://dashboard.stripe.com/account/apikeys' ) ?></li>
                        <li><?php printf( __( 'In the Dashboard\'s <a href="%s" target="_blank">Webhooks settings</a> section, click <b>Add endpoint</b> to reveal a form to add a new endpoint for receiving events.', 'bookly' ), 'https://dashboard.stripe.com/account/webhooks' ) ?></li>
                        <li><?php printf( __( 'Enter the following URL as the destination for events <b>%s</b> and click <b>Add endpoint</b>.', 'bookly' ), admin_url( 'admin-ajax.php?action=bookly_stripe_ipn' ) ) ?></li>
                        <li><?php _e( 'Add these events: <b>payment_intent.succeeded</b>, <b>payment_intent.payment_failed</b> and click <b>Add endpoint</b>.', 'bookly' ) ?></li>
                    </ol>
                </div>
                <?php Inputs::renderText( 'bookly_stripe_publishable_key', __( 'Publishable Key', 'bookly' ) ) ?>
                <?php Inputs::renderText( 'bookly_stripe_secret_key', __( 'Secret Key', 'bookly' ) ) ?>
                <?php Payments::renderPriceCorrection( 'stripe' ) ?>
                <?php
                $values = array( array( '0', __( 'OFF', 'bookly' ) ) );
                foreach ( array_merge(
                    range( 5 * MINUTE_IN_SECONDS, 55 * MINUTE_IN_SECONDS, 5 * MINUTE_IN_SECONDS ),
                    range( HOUR_IN_SECONDS, 23 * HOUR_IN_SECONDS, HOUR_IN_SECONDS ),
                    range( 24 * HOUR_IN_SECONDS, 168 * HOUR_IN_SECONDS, 24 * HOUR_IN_SECONDS ),
                    array( 336 * HOUR_IN_SECONDS, 504 * HOUR_IN_SECONDS, 672 * HOUR_IN_SECONDS )
                ) as $seconds ) {
                    $values[] = array( $seconds, DateTime::secondsToInterval( $seconds ) );
                }
                Selects::renderSingle( 'bookly_stripe_timeout', __( 'Time interval of payment gateway', 'bookly' ), __( 'This setting determines the time limit after which the payment made via the payment gateway is considered to be incomplete. This functionality requires a scheduled cron job.', 'bookly' ), $values );
                ?>
                <?php if ( ! Cloud\API::getInstance()->account->productActive( Cloud\Account::PRODUCT_CRON ) ) : ?>
                <div class="alert alert-info mb-0">
                    <div class="form-row">
                        <div class="mr-3"><i class="fas fa-info-circle fa-2x"></i></div>
                        <div class="align-content-center">
                            <?php printf( __( 'To ensure stable operation of the "Time interval of payment gateway" feature, please activate %s or follow <a href="%s" target="_blank">the instructions</a> about cron setup.', 'bookly' ), '<a href="' . esc_url( admin_url( 'admin.php?page=bookly-cloud-products' ) ) . '">Bookly Cloud Cron</a>', 'https://support.booking-wp-plugin.com/hc/en-us/articles/360015017400-How-can-I-configure-CRON-to-send-the-Bookly-reminders' ) ?>
                        </div>
                    </div>
                </div>
                <?php endif ?>
            </div>
        </div>
    </div>
</div>