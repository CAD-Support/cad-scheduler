<?php
namespace BooklyGroupBooking\Backend\Components\Divi\ProxyProviders;

use Bookly\Backend\Components\Divi\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormFields( array $fields )
    {
        $fields['hide_number_of_persons'] = array(
            'label' => __( 'Hide persons', 'bookly' ),
            'type' => 'yes_no_button',
            'options' => array(
                'off' => esc_html__( 'No', 'bookly' ),
                'on' => esc_html__( 'Yes', 'bookly' ),
            ),
            'default' => 'on',
            'toggle_slug' => 'main_content',
        );

        return $fields;
    }

    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormShortcode( array $shortcode, array $props )
    {
        list( $short_code, $hide ) = $shortcode;

        if ( isset( $props['hide_number_of_persons'] ) && $props['hide_number_of_persons'] !== 'on' ) {
            $short_code .= ' show_number_of_persons="1"';
        }

        return array( $short_code, $hide );
    }
}
