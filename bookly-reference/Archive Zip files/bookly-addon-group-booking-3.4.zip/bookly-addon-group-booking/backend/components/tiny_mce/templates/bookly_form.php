<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<tr>
    <td>
        <label for="bookly-hide-number-of-persons"><?php esc_html_e( 'Persons', 'bookly' ) ?></label>
    </td>
    <td>
        <div class="checkbox">
            <label>
                <input type="checkbox" id="bookly-hide-number-of-persons" checked>
                <?php esc_html_e( 'Hide this field', 'bookly' ) ?>
            </label>
        </div>
    </td>
</tr>