<?php
namespace BooklyPaypalPaymentsStandard\Lib;

class Updater extends \Bookly\Lib\Base\Updater
{
    public function update_3_4()
    {
        $new_pc_key = 'bookly_paypal_payments_standard_purchase_code';
        $old_pc_key = 'bookly_paypal_payments_standard_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_2_9()
    {
        delete_option( 'bookly_paypal_payments_standard_enabled' );
    }

}