<?php
namespace BooklyPaypalPaymentsStandard\Lib;

use BooklyPaypalPaymentsStandard\Backend;

abstract class Plugin extends \Bookly\Lib\Base\Plugin
{
    protected static $prefix;
    protected static $title;
    protected static $version;
    protected static $slug;
    protected static $directory;
    protected static $main_file;
    protected static $basename;
    protected static $text_domain;
    protected static $root_namespace;
    protected static $embedded;

    /**
     * @inheritDoc
     */
    protected static function init()
    {
        // Register proxy methods.
        Backend\Modules\Settings\ProxyProviders\Local::init();
        Backend\Modules\Settings\ProxyProviders\Shared::init();
        if ( get_option( 'bookly_paypal_enabled' ) === 'ps' ) {
            Payment\ProxyProviders\Shared::init();
        }
    }

    /**
     * @inerhitDoc
     */
    public static function deactivate( $network_wide )
    {
        if ( get_option( 'bookly_paypal_enabled' ) === 'ps' ) {
            update_option( 'bookly_paypal_enabled', '0' );
        }
        parent::deactivate( $network_wide );
    }

}
