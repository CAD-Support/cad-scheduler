<?php
namespace BooklyPaypalPaymentsStandard\Lib;

use Bookly\Lib as BooklyLib;

class Installer extends Base\Installer
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->options = array(

        );
    }

    /**
     * Remove data.
     */
    public function removeData()
    {
        if ( get_option( 'bookly_paypal_enabled' ) === 'ps' ) {
            update_option( 'bookly_paypal_enabled', '0' );
        }

        parent::removeData();
    }
}
