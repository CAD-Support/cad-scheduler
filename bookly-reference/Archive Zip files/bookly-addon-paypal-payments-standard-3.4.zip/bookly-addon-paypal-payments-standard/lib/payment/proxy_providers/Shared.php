<?php
namespace BooklyPaypalPaymentsStandard\Lib\Payment\ProxyProviders;

use Bookly\Frontend\Modules\Payment;
use Bookly\Lib\Payment\Proxy;
use Bookly\Lib\Entities;
use BooklyPaypalPaymentsStandard\Lib\Payment\PayPalGateway;

class Shared extends Proxy\Shared
{
    /**
     * @inerhitDoc
     */
    public static function getGatewayByName( $gateway, Payment\Request $request )
    {
        if ( $gateway === Entities\Payment::TYPE_PAYPAL && get_option( 'bookly_paypal_enabled' ) === 'ps' ) {
            return new PayPalGateway( $request );
        }

        return $gateway;
    }

}