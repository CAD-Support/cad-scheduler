<?php
namespace BooklyPaypalPaymentsStandard\Lib\Payment;

use Bookly\Lib as BooklyLib;

class PayPalGateway extends BooklyLib\Base\Gateway
{
    protected $type = BooklyLib\Entities\Payment::TYPE_PAYPAL;

    /**
     * @inerhitDoc
     */
    protected function getCheckoutUrl( array $intent_data )
    {
        return $intent_data['target_url'];
    }

    /**
     * @inerhitDoc
     */
    protected function getInternalMetaData()
    {
        return array();
    }

    /**
     * @inerhitDoc
     */
    protected function createGatewayIntent()
    {
        $data = array(
            'cmd' => '_xclick',
            'business' => get_option( 'bookly_paypal_id' ),
            'amount' => $this->getGatewayAmount(),
            'tax' => $this->getGatewayTax(),
            'currency_code' => BooklyLib\Config::getCurrency(),
            'item_name' => $this->request->getUserData()->cart->getItemsTitle( 127 ),
            'notify_url' => urlencode( $this->getWebHookUrl() ),
            'return' => urlencode( $this->getResponseUrl( self::EVENT_RETRIEVE ) ),
            'cancel_return' => urlencode( $this->getResponseUrl( self::EVENT_CANCEL ) ),
            'email' => $this->request->getUserData()->getEmail(),
            'first_name' => $this->request->getUserData()->getFirstName(),
            'last_name' => $this->request->getUserData()->getLastName(),
            'charset' => 'utf-8',
        );

        return array(
            'target_url' => add_query_arg( $data, $this->getWebscrUrl() ),
        );
    }

    /**
     * @inerhitDoc
     */
    public function retrieveStatus()
    {
        if ( $this->verifyRequest()
            && ( $this->validatePaymentData( $this->request->get( 'mc_gross' ), $this->request->get( 'mc_currency' ) ) )
            && ( $this->request->get( 'receiver_email' ) == get_option( 'bookly_paypal_id' ) || $this->request->get( 'receiver_id' ) == get_option( 'bookly_paypal_id' ) )
        ) {
            switch ( $this->request->get( 'payment_status' ) ) {
                case 'Completed':
                    $this->payment->setRefId( $this->request->get( 'txn_id' ) );
                    return self::STATUS_COMPLETED;
                case 'Denied':
                case 'Expired':
                case 'Failed':
                case 'Reversed':
                case 'Voided':
                    return self::STATUS_FAILED;
                case 'Canceled_Reversal':
                case 'Created':
                case 'Pending':
                case 'Refunded':
                case 'Processed':
                default:
                    break;
            }
        }

        return self::STATUS_PROCESSING;
    }

    /**
     * @return string
     */
    private function getWebscrUrl()
    {
        return get_option( 'bookly_paypal_sandbox' )
            ? 'https://www.sandbox.paypal.com/cgi-bin/webscr'
            : 'https://www.paypal.com/cgi-bin/webscr';
    }

    /**
     * @return bool
     */
    private function verifyRequest()
    {
        $body = $_POST;
        $body['cmd'] = '_notify-validate';

        $response = wp_safe_remote_post( $this->getWebscrUrl(), compact( 'body' ) );

        return wp_remote_retrieve_body( $response ) === 'VERIFIED';
    }
}