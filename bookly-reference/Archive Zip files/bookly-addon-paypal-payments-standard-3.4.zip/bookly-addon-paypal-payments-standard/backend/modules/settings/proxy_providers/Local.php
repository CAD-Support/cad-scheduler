<?php
namespace BooklyPaypalPaymentsStandard\Backend\Modules\Settings\ProxyProviders;

use Bookly\Backend\Modules\Settings\Proxy;
use BooklyPro\Lib\Payment\PayPalGateway;

class Local extends Proxy\PaypalPaymentsStandard
{
    /**
     * @inheritDoc
     */
    public static function prepareToggleOptions( array $options )
    {
        $options[] = array( PayPalGateway::TYPE_PAYMENTS_STANDARD, 'PayPal Payments Standard' );

        return $options;
    }

    /**
     * @inheritDoc
     */
    public static function renderSetUpOptions()
    {
        self::renderTemplate( 'options' );
    }
}