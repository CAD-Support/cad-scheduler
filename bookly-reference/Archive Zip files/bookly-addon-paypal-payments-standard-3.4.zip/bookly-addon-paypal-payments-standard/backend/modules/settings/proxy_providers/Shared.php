<?php
namespace BooklyPaypalPaymentsStandard\Backend\Modules\Settings\ProxyProviders;

use Bookly\Backend\Modules\Settings\Proxy;
use BooklyPaypalPaymentsStandard\Lib;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function saveSettings( array $alert, $tab, array $params )
    {
        if ( $tab === 'payments' ) {
            $options = array(
                'bookly_paypal_id',
            );
            foreach ( $options as $option_name ) {
                if ( array_key_exists( $option_name, $params ) ) {
                    update_option( $option_name, trim( $params[ $option_name ] ) );
                }
            }
        }

        return $alert;
    }
}