<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Settings\Inputs;
?>
<div class="bookly-paypal-ps">
    <?php Inputs::renderText( 'bookly_paypal_id', __( 'PayPal ID', 'bookly' ), __( 'Your PayPal ID or an email address associated with your PayPal account. Email addresses must be confirmed.', 'bookly' ) ) ?>
</div>
