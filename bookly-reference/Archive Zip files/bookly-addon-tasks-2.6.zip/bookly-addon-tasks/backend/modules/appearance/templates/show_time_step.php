<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Inputs;
?>
<div class="col-lg-4 col-xl-3 mb-2">
    <?php Inputs::renderCheckBox( __( 'Show Time step', 'bookly' ), null, get_option( 'bookly_tasks_show_time_step' ), array( 'id' => 'bookly-tasks-show-time-step', 'data-target' => 'bookly-step-3', 'data-type' => 'bookly-show-step-checkbox' ) ) ?>
</div>