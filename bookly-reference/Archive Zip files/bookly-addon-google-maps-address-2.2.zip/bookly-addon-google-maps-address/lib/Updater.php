<?php
namespace BooklyGoogleMapsAddress\Lib;

use Bookly\Lib as BooklyLib;

class Updater extends BooklyLib\Base\Updater
{
    public function update_2_1()
    {
        $new_pc_key = 'bookly_google_maps_address_purchase_code';
        $old_pc_key = 'bookly_google_maps_address_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_1_4()
    {
        $this->addL10nOptions( array(
            'bookly_l10n_label_google_maps' => __( 'Address', 'bookly' ),
        ) );
    }
}