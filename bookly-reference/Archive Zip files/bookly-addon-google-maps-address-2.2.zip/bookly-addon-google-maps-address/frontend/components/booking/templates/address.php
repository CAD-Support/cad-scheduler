<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Lib as BooklyLib;
/** @var string $form_id */
?>
<div class="bookly-box">
    <div class="bookly-form-group">
        <label for="bookly-gm-<?php echo $form_id ?>"><?php echo BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_label_google_maps' ) ?></label>
        <div>
            <input class="bookly-js-cst-address-autocomplete" type="text" placeholder="" id="bookly-gm-<?php echo $form_id ?>"/>
        </div>
    </div>
</div>