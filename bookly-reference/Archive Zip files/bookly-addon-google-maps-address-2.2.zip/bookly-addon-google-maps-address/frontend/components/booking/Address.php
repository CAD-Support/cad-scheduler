<?php
namespace BooklyGoogleMapsAddress\Frontend\Components\Booking;

use Bookly\Lib as BooklyLib;

class Address extends BooklyLib\Base\Component
{
    /**
     * @param string $form_id
     * @return void
     */
    public static function render( $form_id )
    {
        self::renderTemplate( 'address', compact( 'form_id' ) );
    }
}