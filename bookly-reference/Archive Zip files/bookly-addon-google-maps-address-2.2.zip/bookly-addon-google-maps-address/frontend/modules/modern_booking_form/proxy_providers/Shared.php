<?php
namespace BooklyGoogleMapsAddress\Frontend\Modules\ModernBookingForm\ProxyProviders;

use Bookly\Frontend\Modules\ModernBookingForm\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inerhitDoc
     */
    public static function prepareFormOptions( array $bookly_options )
    {
        $bookly_options['google_maps_relations'] = array(
            'country' => array( 'country' ),
            'postcode' => array( 'postal_code' ),
            'city' => array( 'locality', 'administrative_area_level_3', 'postal_town' ),
            'state' => array( 'administrative_area_level_1' ),
            'street' => array( 'route' ),
            'street_number' => array( 'street_number' ),
            'additional_address' => array( 'subpremise', 'neighborhood', 'sublocality' ),
        );

        $bookly_options['google_api_key'] = get_option( 'bookly_google_api_key' );

        return $bookly_options;
    }

    /**
     * @inerhitDoc
     */
    public static function prepareAppearance( array $bookly_options )
    {
        $bookly_options['l10n']['google_maps'] = __( 'Google maps address', 'bookly' );

        return $bookly_options;
    }

    /**
     * @inerhitDoc
     */
    public static function prepareAppearanceData( array $bookly_options )
    {
        $bookly_options['details_fields']['google_maps'] = __( 'Google maps address', 'bookly' );

        return $bookly_options;
    }
}