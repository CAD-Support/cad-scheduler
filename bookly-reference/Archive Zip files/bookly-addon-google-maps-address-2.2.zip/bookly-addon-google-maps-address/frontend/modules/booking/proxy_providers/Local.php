<?php
namespace BooklyGoogleMapsAddress\Frontend\Modules\Booking\ProxyProviders;

use Bookly\Frontend\Modules\Booking\Proxy;
use Bookly\Lib\UserBookingData;
use BooklyGoogleMapsAddress\Frontend\Components;

class Local extends Proxy\GoogleMapsAddress
{
    /**
     * @inheritDoc
     */
    public static function renderAutocompleter( UserBookingData $userData )
    {
        Components\Booking\Address::render( $userData->getFormId() );
    }
}