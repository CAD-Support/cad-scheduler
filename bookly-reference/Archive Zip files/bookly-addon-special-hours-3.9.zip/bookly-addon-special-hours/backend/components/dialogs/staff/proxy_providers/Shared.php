<?php
namespace BooklySpecialHours\Backend\Components\Dialogs\Staff\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Components\Dialogs\Staff\Proxy;
use BooklySpecialHours\Lib\Entities;

class Shared extends Proxy\Shared
{
    /**
     * @inheriDoc
     */
    public static function duplicateStaff( $original_staff_id, $new_staff )
    {
        /** @var Entities\StaffSpecialHour[] $special_hours */
        $special_hours = Entities\StaffSpecialHour::query()
            ->where( 'staff_id', $original_staff_id )
            ->find();

        foreach ( $special_hours as $special_hour ) {
            $new_special_hour = new Entities\StaffSpecialHour();
            $new_special_hour
                ->setStaffId( $new_staff->getId() )
                ->setServiceId( $special_hour->getServiceId() )
                ->setLocationId( $special_hour->getLocationId() )
                ->setStartTime( $special_hour->getStartTime() )
                ->setEndTime( $special_hour->getEndTime() )
                ->setDays( $special_hour->getDays() )
                ->setPrice( $special_hour->getPrice() )
                ->save();
        }

        return $original_staff_id;
    }
}