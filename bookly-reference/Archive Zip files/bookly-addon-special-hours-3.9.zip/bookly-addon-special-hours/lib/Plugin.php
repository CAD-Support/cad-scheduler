<?php
namespace BooklySpecialHours\Lib;

use BooklySpecialHours\Backend\Components;
use BooklySpecialHours\Backend;
use BooklySpecialHours\Frontend;

abstract class Plugin extends \Bookly\Lib\Base\Plugin
{
    protected static $prefix;
    protected static $title;
    protected static $version;
    protected static $slug;
    protected static $directory;
    protected static $main_file;
    protected static $basename;
    protected static $text_domain;
    protected static $root_namespace;
    protected static $embedded;

    /**
     * @inheritDoc
     */
    protected static function init()
    {
        // Register proxy methods.
        Frontend\Modules\Booking\ProxyProviders\Shared::init();
        Frontend\Modules\ModernBookingForm\ProxyProviders\Shared::init();
        Backend\Modules\Staff\ProxyProviders\Shared::init();
        Backend\Modules\Appearance\ProxyProviders\Local::init();
        Backend\Modules\Appearance\ProxyProviders\Shared::init();
        Components\Dialogs\SpecialPrice\ProxyProviders\Local::init();
        Components\Dialogs\Staff\Edit\ProxyProviders\Shared::init();
        Components\Dialogs\Staff\ProxyProviders\Shared::init();
        Components\TinyMce\ProxyProviders\Local::init();
        ProxyProviders\Local::init();
    }

    /**
     * @inheritDoc
     */
    protected static function registerAjax()
    {
        Components\Dialogs\Staff\Edit\Ajax::init();
    }
}