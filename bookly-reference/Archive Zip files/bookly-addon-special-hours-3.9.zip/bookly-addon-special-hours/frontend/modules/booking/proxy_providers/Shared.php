<?php
namespace BooklySpecialHours\Frontend\Modules\Booking\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Frontend\Modules\Booking\Proxy;
use BooklySpecialHours\Lib\Entities\StaffSpecialHour;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareSlotsData( $slots_data )
    {
        if ( get_option( 'bookly_app_highlight_special_hours', false ) ) {
            $special_hours_data = StaffSpecialHour::query()->fetchArray();
            $special_hours = array();
            foreach ( $special_hours_data as $special_hour_data ) {
                $start_time = BooklyLib\Utils\DateTime::timeToSeconds( $special_hour_data['start_time'] );
                $end_time = BooklyLib\Utils\DateTime::timeToSeconds( $special_hour_data['end_time'] );
                foreach ( explode( ',', $special_hour_data['days'] ) as $day ) {
                    $special_hours[] = array(
                        'start_time' => $start_time,
                        'end_time' => $end_time,
                        'staff_id' => $special_hour_data['staff_id'],
                        'service_id' => $special_hour_data['service_id'],
                        'location_id' => $special_hour_data['location_id'],
                        'day' => trim( $day ),
                    );
                    if ( $end_time > DAY_IN_SECONDS ) {
                        $special_hours[] = array(
                            'start_time' => 0,
                            'end_time' => $end_time - DAY_IN_SECONDS,
                            'staff_id' => $special_hour_data['staff_id'],
                            'service_id' => $special_hour_data['service_id'],
                            'location_id' => $special_hour_data['location_id'],
                            'day' => trim( $day % 7 + 1 ),
                        );
                    }
                }
            }
            foreach ( $slots_data as &$slot_data ) {
                foreach ( $slot_data['slots'] as &$slot ) {
                    /** @var BooklyLib\Slots\Range $current_slot */
                    $current_slot = $slot['slot'];
                    $location_id = BooklyLib\Proxy\Locations::prepareStaffLocationId( $current_slot->locationId(), $current_slot->staffId() ) ?: null;
                    foreach ( $special_hours as $special_hour ) {
                        if (
                            $current_slot->staffId() == $special_hour['staff_id'] &&
                            $current_slot->serviceId() == $special_hour['service_id'] &&
                            $location_id == $special_hour['location_id'] &&
                            $current_slot->start()->value()->format( 'w' ) + 1 == $special_hour['day'] &&
                            BooklyLib\Utils\DateTime::timeToSeconds( $current_slot->start()->value()->format( 'H:i:s' ) ) < $special_hour['end_time'] &&
                            BooklyLib\Utils\DateTime::timeToSeconds( $current_slot->start()->value()->format( 'H:i:s' ) ) + $current_slot->end()->diff( $current_slot->start() ) > $special_hour['start_time']
                        ) {
                            $slot['special_hour'] = true;
                        }
                    }
                }
            }
        }

        return $slots_data;
    }
}