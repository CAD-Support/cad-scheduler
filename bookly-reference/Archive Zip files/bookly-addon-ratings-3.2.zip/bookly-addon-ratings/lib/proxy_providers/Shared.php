<?php
namespace BooklyRatings\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;

class Shared extends BooklyLib\Proxy\Shared
{
    /**
     * Add the Ratings tab to the Settings submenu in the fullscreen header sidebar.
     *
     * @param array $submenus
     * @return array
     */
    public static function buildHeaderSubmenus( $submenus )
    {
        if ( isset( $submenus['bookly-settings'] ) ) {
            $submenus['bookly-settings'][] = array( 'label' => __( 'Ratings', 'bookly' ), 'tab' => 'ratings', 'badge' => '' );
        }

        return $submenus;
    }

    /**
     * @inheritDoc
     */
    public static function prepareTableColumns( $columns, $table )
    {
        if ( $table == BooklyLib\Utils\Tables::APPOINTMENTS ) {
            $columns['rating'] = __( 'Rating', 'bookly' );
        }

        return $columns;
    }
}