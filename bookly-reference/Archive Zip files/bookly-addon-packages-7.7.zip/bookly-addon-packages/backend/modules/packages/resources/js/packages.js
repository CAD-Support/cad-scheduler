jQuery(function ($) {
    'use strict';

    const table = 'packages';
    const fl = BooklyPackagesL10n.filters;
    const $list = $('#bookly-packages-datatables');

    let isMobile = false;
    try { document.createEvent('TouchEvent'); isMobile = true; } catch (e) { /* not touch */ }

    // ── Date filter (defaults to current month, like the legacy page) ────
    const { today, getLocalTimeZone, parseDate } = window.BooklyDatatables.calendarDate;
    const tz = getLocalTimeZone();
    const t = today(tz);
    const startOfMonth = d => d.set({ day: 1 });
    const endOfMonth = d => d.set({ day: 1 }).add({ months: 1 }).subtract({ days: 1 });
    const ymd = d => d.year + '-' + String(d.month).padStart(2, '0') + '-' + String(d.day).padStart(2, '0');
    function serializeDate(value) {
        if (!value || !value.start || !value.end) return 'any';
        return ymd(value.start) + ' - ' + ymd(value.end);
    }
    const datePresets = [
        { label: BooklyPackagesL10n.dateRange.yesterday, range: { start: t.subtract({ days: 1 }),  end: t.subtract({ days: 1 }) } },
        { label: BooklyPackagesL10n.dateRange.today,     range: { start: t,                        end: t                       } },
        { label: BooklyPackagesL10n.dateRange.tomorrow,  range: { start: t.add({ days: 1 }),       end: t.add({ days: 1 })      } },
        { label: BooklyPackagesL10n.dateRange.last_7,    range: { start: t.subtract({ days: 7 }),  end: t                       } },
        { label: BooklyPackagesL10n.dateRange.last_30,   range: { start: t.subtract({ days: 30 }), end: t                       } },
        { label: BooklyPackagesL10n.dateRange.thisMonth, range: { start: startOfMonth(t),                    end: endOfMonth(t)                    } },
        { label: BooklyPackagesL10n.dateRange.nextMonth, range: { start: startOfMonth(t.add({ months: 1 })), end: endOfMonth(t.add({ months: 1 })) } },
    ];

    // ── Filter state ─────────────────────────────────────────────────────
    const savedFilter = BooklyPackagesL10n.datatables[table].settings.filter || {};
    // Default to current month; restore the saved range if present ('any' → no date filter).
    let dateValue = { start: startOfMonth(t), end: endOfMonth(t) };
    if (savedFilter.date === 'any') {
        dateValue = undefined;
    } else if (savedFilter.date) {
        const parts = String(savedFilter.date).split(' - ');
        if (parts.length === 2) {
            try { dateValue = { start: parseDate(parts[0].trim()), end: parseDate(parts[1].trim()) }; } catch (e) { /* keep default */ }
        }
    }
    let staffValue = (savedFilter.staff !== undefined && savedFilter.staff !== '') ? String(savedFilter.staff) : '';
    let customerValue = savedFilter.customer ? String(savedFilter.customer) : '';
    let packageValue = savedFilter.package ? String(savedFilter.package) : '';
    let serviceValue = savedFilter.service ? String(savedFilter.service) : '';

    const staffOptions = [{ value: '0', label: fl.unassigned }].concat(
        (BooklyPackagesL10n.staffMembers || []).map(s => ({ value: String(s.id), label: s.full_name }))
    );
    const packageOptions = (BooklyPackagesL10n.packages || []).map(p => ({ value: String(p.id), label: p.title }));
    const serviceOptions = (BooklyPackagesL10n.services || []).map(s => ({ value: String(s.id), label: s.title }));
    const customerOptions = (BooklyPackagesL10n.customers || []).map(c => ({ value: String(c.id), label: c.full_name }));

    /**
     * Init columns.
     */
    let columns = [];

    // Backend (Ajax::getPackages) searches by p.id, c.full_name, c.phone,
    // c.email, st.full_name, s.title, ps.title — only these columns are searchable.
    const searchableColumns = ['id', 'staff_name', 'customer_full_name', 'customer_phone', 'customer_email', 'package_title', 'service_title'];

    $.each(BooklyPackagesL10n.datatables[table].settings.columns, function (column, show) {
        switch (column) {
            case 'created_at':
                columns.push({
                    data: 'created_at',
                    // Creation time rendered as a muted secondary line below the date.
                    secondary: row => row.created_time || '',
                });
                break;
            case 'staff_name':
                columns.push({ data: 'staff.name', render: BooklyDatatables.escapeHtml() });
                break;
            case 'customer_full_name':
                columns.push({ data: 'customer.full_name', render: BooklyDatatables.escapeHtml() });
                break;
            case 'customer_phone':
                columns.push({
                    data: 'customer.phone',
                    parent: 'customer_full_name',
                    render: function (data) {
                        const phone = BooklyDatatables.escapeHtml(data);
                        return isMobile && data ? '<a href="tel:' + phone + '">' + phone + '</a>' : phone;
                    }
                });
                break;
            case 'customer_email':
                columns.push({ data: 'customer.email', parent: 'customer_full_name', render: BooklyDatatables.escapeHtml() });
                break;
            case 'package_title':
                columns.push({ data: 'package.title', render: BooklyDatatables.escapeHtml() });
                break;
            case 'service_title':
                columns.push({ data: 'service.title', render: BooklyDatatables.escapeHtml() });
                break;
            case 'package_size':
                columns.push({ data: 'package.size', render: BooklyDatatables.escapeHtml() });
                break;
            case 'payment':
                columns.push({
                    data: 'payment_amount',
                    // Two lines: amount (primary) + "gateway · status" (muted secondary).
                    secondary: row => row.payment_gateway || row.payment_status
                        ? [row.payment_gateway, row.payment_status].filter(Boolean).join(' · ')
                        : null,
                    render: function (data, type, row) {
                        if (row.payment_id) {
                            return '<a type="button" data-action="show-payment" class="bookly:text-primary bookly:cursor-pointer" data-payment_id="' + row.payment_id + '">' + data + '</a>';
                        }
                        return data || '';
                    }
                });
                break;
            default:
                columns.push({ data: column.replace('_', '.'), render: BooklyDatatables.escapeHtml() });
                break;
        }
        columns[columns.length - 1].title = BooklyPackagesL10n.datatables[table].titles[column] || column;
        columns[columns.length - 1].name = column;
        columns[columns.length - 1].show = show;
        columns[columns.length - 1].searchable = searchableColumns.indexOf(column) !== -1;
    });

    // ── Customer filter (static list or remote AJAX typeahead) ───────────
    const customerFilter = {
        type: 'select',
        name: 'customer',
        label: fl.customer,
        initialValue: customerValue,
        searchPlaceholder: fl.searchPlaceholder,
        options: customerOptions,
        onChange: function (v) { customerValue = v; },
    };
    if (BooklyPackagesL10n.customersRemote) {
        customerFilter.remote = true;
        customerFilter.loadOptions = function (term) {
            return $.ajax({
                url: ajaxurl, method: 'POST', dataType: 'json',
                data: { action: 'bookly_get_customers_list', filter: term || '', page: 1, csrf_token: BooklyL10nGlobal.csrf_token }
            }).then(resp => (resp && resp.results ? resp.results : []).map(c => ({ value: String(c.id), label: c.text })));
        };
        customerFilter.resolveOption = function (id) {
            return $.ajax({
                url: ajaxurl, method: 'POST', dataType: 'json',
                data: { action: 'bookly_get_customers_list', ids: [id], csrf_token: BooklyL10nGlobal.csrf_token }
            }).then(resp => { const c = resp && resp.results && resp.results[0]; return c ? { value: String(c.id), label: c.text } : null; });
        };
    }

    /**
     * Init datatable.
     */
    let bt = BooklyDatatables.showForm('bookly-' + table + '-datatables', {
        datePicker: BooklyPackagesL10n.datePicker,
        ajax: {
            url: ajaxurl,
            method: 'POST',
            data: function (d) {
                return $.extend({
                    action: 'bookly_packages_get_packages',
                    csrf_token: BooklyL10nGlobal.csrf_token,
                    filter: {
                        date: serializeDate(dateValue),
                        staff: staffValue,
                        customer: customerValue,
                        package: packageValue,
                        service: serviceValue
                    }
                }, d);
            }
        },
        columns: columns,
        tableSettings: Object.assign({}, BooklyPackagesL10n.datatables[table], {
            l10n: Object.assign({}, BooklyPackagesL10n.datatables.l10n, { zeroRecords: BooklyPackagesL10n.zeroRecords })
        }),
        edit: function (row) {
            BooklyPackageDialog.showDialog(row.id, function () { bt.reload(); });
        },
        rowActions: function () {
            return [{
                label: BooklyPackagesL10n.schedule,
                icon: 'calendar',
                variant: 'outline',
                click: function (r) {
                    $(document.body).trigger('bookly_packages.schedule_dialog', [r.id, function () { bt.reload(); }]);
                }
            }];
        },
        checked: function () {
            return [{
                label: BooklyPackagesL10n.delete,
                icon: 'trash',
                variant: 'destructive',
                click: function (selected) {
                    new BooklyConfirmDeletingAppointment(
                        {
                            action: 'bookly_packages_delete_packages',
                            csrf_token: BooklyL10nGlobal.csrf_token,
                            data: selected.map(function (r) { return r.id; })
                        },
                        function () { bt.reload(); }
                    );
                }
            }];
        },
        searchFilter: {
            placeholder: BooklyPackagesL10n.search,
            name: 'filter[search]'
        },
        saveSettings: function (settings) {
            $.post(ajaxurl, Object.assign({
                action: 'bookly_update_table_settings',
                table: table,
                csrf_token: BooklyL10nGlobal.csrf_token
            }, settings));
        },
        filters: [
            { type: 'dateRange', name: 'date', label: fl.date, initialValue: dateValue, presets: datePresets, onChange: function (v) { dateValue = v; } },
            { type: 'select', name: 'staff', label: fl.staff, initialValue: staffValue, searchPlaceholder: fl.searchPlaceholder, options: staffOptions, onChange: function (v) { staffValue = v; } },
            customerFilter,
            { type: 'select', name: 'package', label: fl.package, initialValue: packageValue, searchPlaceholder: fl.searchPlaceholder, options: packageOptions, onChange: function (v) { packageValue = v; } },
            { type: 'select', name: 'service', label: fl.service, initialValue: serviceValue, searchPlaceholder: fl.searchPlaceholder, options: serviceOptions, onChange: function (v) { serviceValue = v; } },
        ],
        topToolbar: [{
            id: 'bookly-new-package',
            label: BooklyPackagesL10n.new_package,
            icon: 'plus',
            variant: 'default',
            click: function () {
                BooklyPackageDialog.showDialog(null, function () { bt.reload(); });
            }
        }]
    });

    /**
     * Show payment details (delegated — the payment cell carries its own payment_id).
     */
    $list.on('click', '[data-action=show-payment]', function () {
        BooklyPaymentDetailsDialog.showDialog({
            payment_id: $(this).data('payment_id'),
            target: 'packages',
            done: function () { bt.reload(); }
        });
    });
});
