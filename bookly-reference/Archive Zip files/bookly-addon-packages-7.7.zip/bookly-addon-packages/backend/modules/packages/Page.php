<?php
namespace BooklyPackages\Backend\Modules\Packages;

use Bookly\Lib as BooklyLib;
use Bookly\Lib\Entities;
use Bookly\Lib\Utils;
use Bookly\Lib\DataHolders;

class Page extends BooklyLib\Base\Component
{
    /**
     * Render page.
     */
    public static function render()
    {
        self::enqueueStyles( array(
            'alias' => array( 'bookly-backend-globals', ),
        ) );

        self::enqueueScripts( array(
            // datatables + svelte-core + tailwind come from bookly-backend-globals.
            'module' => array(
                'js/packages.js' => array( 'bookly-backend-globals' ),
            ),
        ) );

        $datatables = BooklyLib\Utils\Tables::getSettings( BooklyLib\Utils\Tables::PACKAGES );

        // Filters data
        $staff_members = Entities\Staff::query( 's' )->select( 's.id, s.full_name' )->fetchArray();
        $customers = BooklyLib\Entities\Customer::query()->count() < BooklyLib\Entities\Customer::REMOTE_LIMIT
            ? BooklyLib\Entities\Customer::query( 'c' )->select( 'c.id, c.full_name, c.email, c.phone' )->fetchArray()
            : false;
        $packages = Entities\Service::query( 's' )->select( 's.id, s.title' )->where( 'type', Entities\Service::TYPE_PACKAGE )->fetchArray();
        $services = Entities\Service::query( 's' )->select( 's.id, s.title' )->where( 'type', Entities\Service::TYPE_SIMPLE )->fetchArray();

        wp_localize_script( 'bookly-packages.js', 'BooklyPackagesL10n', array(
            'new_package' => __( 'New package', 'bookly' ) . '…',
            'edit_package' => __( 'Edit package', 'bookly' ),
            'datePicker' => Utils\DateTime::datePickerOptions(),
            'dateRange' => Utils\DateTime::dateRangeOptions(),
            'are_you_sure' => __( 'Are you sure?', 'bookly' ),
            'zeroRecords' => __( 'No packages for selected period and criteria.', 'bookly' ),
            'scheduleAppointments' => __( 'Package schedule', 'bookly' ),
            'editPackage' => __( 'Edit package', 'bookly' ),
            'edit' => __( 'Edit', 'bookly' ),
            'schedule' => __( 'Schedule', 'bookly' ) . '…',
            'delete' => __( 'Delete', 'bookly' ) . '…',
            'search' => __( 'Quick search by No., customer, staff, service', 'bookly' ) . '…',
            'no_result_found' => __( 'No results found', 'bookly' ),
            'searching' => __( 'Searching', 'bookly' ),
            'filters' => array(
                'date' => __( 'Creation date', 'bookly' ),
                'staff' => esc_html( BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_label_employee' ) ),
                'customer' => __( 'Customer', 'bookly' ),
                'package' => __( 'Package', 'bookly' ),
                'service' => esc_html( BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_label_service' ) ),
                'unassigned' => __( 'Unassigned', 'bookly' ),
                'searchPlaceholder' => __( 'Search', 'bookly' ) . '…',
            ),
            'customersRemote' => $customers === false,
            'staffMembers' => $staff_members,
            'customers' => $customers ?: array(),
            'packages' => $packages,
            'services' => $services,
            'datatables' => $datatables,
        ) );

        self::renderTemplate( 'index', compact( 'datatables' ) );
    }
}