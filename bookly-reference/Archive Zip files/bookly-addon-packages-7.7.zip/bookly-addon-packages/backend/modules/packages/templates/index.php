<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Dialogs\Appointment;
use Bookly\Backend\Components\Dialogs\Queue;
use Bookly\Backend\Components\Dialogs\Customer;
use Bookly\Backend\Components\PageHeader\Renderer as PageHeaderRenderer;
use BooklyPackages\Backend\Components\Dialogs;
/** @var array $datatables */
?>
<div id="bookly-tbs" class="wrap bookly-css-root bookly-main-page-wrap">
    <?php PageHeaderRenderer::render( $self::pageSlug(), __( 'Packages', 'bookly' ) ) ?>
    <div class="bookly:card">
        <div class="bookly:card-body">
            <div id="bookly-packages-datatables"></div>
        </div>
    </div>
    <?php Appointment\Delete\Dialog::render() ?>
    <?php Dialogs\Schedule\Dialog::render() ?>
    <?php Dialogs\Package\Dialog::render() ?>
    <?php Customer\Edit\Dialog::render() ?>
    <?php Queue\Dialog::render() ?>
</div>
