<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
/**
 * @var array $service
 */
?>
<div id="bookly-js-service-packages-advanced">
    <div class="form-group">
        <label><?php esc_html_e( 'Unassigned', 'bookly' ) ?></label>
        <div class="custom-control custom-radio">
            <input type="radio" id="bookly-package-unassigned-0" name="package_unassigned" value="0"<?php checked( $service['package_unassigned'], 0 ) ?> class="custom-control-input"/>
            <label for="bookly-package-unassigned-0" class="custom-control-label"><?php esc_html_e( 'Disabled', 'bookly' ) ?></label>
        </div>
        <div class="custom-control custom-radio">
            <input type="radio" id="bookly-package-unassigned-1" name="package_unassigned" value="1"<?php checked( $service['package_unassigned'], 1 ) ?> class="custom-control-input"/>
            <label for="bookly-package-unassigned-1" class="custom-control-label"><?php esc_html_e( 'Enabled', 'bookly' ) ?></label>
        </div>
        <small class="form-text text-muted"><?php esc_html_e( 'Enable this setting so that the package can be displayed and available for booking when clients have not specified a particular provider.', 'bookly' ) ?></small>
    </div>
    <div class="form-group">
        <label for="package_life_time_type"><?php esc_html_e( 'Life Time', 'bookly' ) ?></label>
        <select class="form-control custom-select" id="package_life_time_type" name="package_life_time_type">
            <option value="first_booking" <?php selected( $service['package_life_time_type'], 'first_booking' ) ?>><?php esc_html_e( 'Days from the first booking', 'bookly' ) ?></option>
            <option value="creation_date" <?php selected( $service['package_life_time_type'], 'creation_date' ) ?>><?php esc_html_e( 'Days from the creation', 'bookly' ) ?></option>
        </select>
    </div>
    <div class="form-group bookly-js-preferred-staff-order border-left ml-4 pl-3">
        <label for="package_life_time"><?php esc_html_e( 'Number of days', 'bookly' ) ?></label>
        <input id="package_life_time" class="form-control" type="number" min="0" step="1" name="package_life_time" value="<?php echo esc_attr( (int) $service['package_life_time'] ) ?>">
        <small class="form-text text-muted"><?php esc_html_e( 'The period in days when the customer can use a package of services.', 'bookly' ) ?></small>
    </div>
</div>
