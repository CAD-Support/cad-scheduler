jQuery(function ($) {
    $(document.body).on('service.submitForm', {},
        // Bind submit handler for service saving.
        function (event, $panel, data) {
            if ($panel.find('[name="type"]').val() == 'package') {
                data.sub_services = [$('.bookly-js-package-sub-service', $panel).val()];
            }
        }
    );
});