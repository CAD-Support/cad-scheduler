<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
/**
 * @var array $simple_services
 * @var array $service
 */
?>
<div id="bookly-js-service-packages">
    <div class="form-group">
        <label for="package_service"><?php esc_html_e( 'Service', 'bookly' ) ?></label>
        <select class="form-control custom-select bookly-js-package-sub-service" id="package_service" name="package_service">
            <option value="0"><?php esc_html_e( 'Select service', 'bookly' ) ?></option>
            <?php foreach ( $simple_services as $_service ) : ?>
                <?php if ( $_service['id'] != $service['id'] ) : ?>
                    <option value="<?php echo $_service['id'] ?>"<?php if ( isset( $service['sub_services'][0] ) ) {
                        selected( $_service['id'], $service['sub_services'][0]['sub_service_id'] );
                    } ?>><?php echo esc_html( $_service['title'] ) ?></option>
                <?php endif ?>
            <?php endforeach ?>
        </select>
        <div class="alert alert-danger form-group mt-2 p-1 bookly-collapse"><i class="fas pl-1 fa-times mr-2"></i><?php esc_html_e( 'Please select a service', 'bookly' ) ?></div>
        <input type="hidden" id="bookly-js-package-service-changed" name="package_service_changed" value="0"/>
    </div>
    <div class="form-group">
        <label for="package_size"><?php esc_html_e( 'Quantity', 'bookly' ) ?></label>
        <input id="package_size" class="form-control" type="number" min="1" step="1" name="package_size" value="<?php echo esc_attr( $service['package_size'] ?: 10 ) ?>">
    </div>
</div>