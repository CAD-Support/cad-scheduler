(function ($) {
    'use strict';

    /**
     * Customer Packages list — ported to BooklyDatatables.showForm().
     * One row action (Package schedule) surfaced as a row action (hover strip + single-row
     * selection toolbar) so it stays reachable at any screen size.
     */
    window.booklyCustomerPackages = function (Options) {
        const $container = $('.bookly-js-customer-packages-' + Options.form_id);
        if (!$container.length) {
            return;
        }
        const L = BooklyCustomerPackagesL10n;
        const dt = L.datatables;
        const mountId = 'bookly-packages-list-' + Options.form_id;

        const columns = [
            { data: 'package.title', name: 'title',      title: L.titles.title },
            { data: 'created_at',    name: 'created_at', title: L.titles.created_at },
            { data: 'expires',       name: 'expires',    title: L.titles.expires, orderable: false },
            { data: 'staff.name',    name: 'staff',      title: L.titles.staff },
            { data: 'service.title', name: 'service',    title: L.titles.service },
            { data: 'package.size',  name: 'size',       title: L.titles.size },
        ];
        columns.forEach(function (c) { c.show = true; c.render = BooklyDatatables.escapeHtml(); });

        const options = {
            // Customer-facing: no admin Settings/Refresh, no column persistence.
            reloadButton: false,
            settingsButton: false,
            getId: row => String(row.id),
            rowActions: function (row) {
                return [{
                    label: L.scheduleAppointments,
                    icon: 'calendar',
                    variant: 'outline',
                    click: function (r) {
                        $(document.body).trigger('bookly_packages.schedule_dialog', [
                            r.id,
                            function () { bt.reload(); },
                            null,
                            L.useClientTimeZone != '1',
                        ]);
                    },
                }];
            },
            ajax: {
                url: Options.ajaxurl,
                method: 'POST',
                data: function () {
                    return { action: 'bookly_packages_get_packages', csrf_token: BooklyL10nGlobal.csrf_token, filter: {} };
                },
            },
            columns: columns,
            // Self-contained table settings (legacy was hardcoded too) — not from any backend
            // table. Only the l10n strings are the shared, table-agnostic datatables UI strings.
            tableSettings: {
                settings: { order: [[1, 'desc']], page_length: 25, appearance: { responsive_table: true } },
                defaults: { columns: {}, order: [], page_length: 25, appearance: { responsive_table: true } },
                titles: L.titles,
                l10n: Object.assign({}, dt.l10n, { zeroRecords: L.zeroRecords }),
            },
        };

        const bt = BooklyDatatables.showForm(mountId, options);
    };
})(jQuery);
