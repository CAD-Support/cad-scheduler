<?php
namespace BooklyOutlookCalendar\Frontend\Modules\Outlook;

use Bookly\Lib as BooklyLib;
use BooklyOutlookCalendar\Lib;
use BooklyPro\Lib\Config as ProConfig;

class Ajax extends BooklyLib\Base\Ajax
{
    /**
     * @inheritDoc
     */
    protected static function permissions()
    {
        return array( '_default' => 'anonymous' );
    }

    /**
     * Process PUSH notifications.
     */
    public static function pushNotifications()
    {
        if ( self::hasParameter( 'validationToken' ) ) {
            // Notification endpoint validation.
            @header( 'Content-Type: text/plain' );
            exit ( self::parameter( 'validationToken' ) );
        }

        // Process notification.
        if ( ! ProConfig::graceExpired() && Lib\Config::getSyncMode() == '2-way' ) {
            $json = file_get_contents( 'php://input' );
            $data = (array) json_decode( $json, true );
            if ( isset ( $data['value'] ) && is_array( $data['value'] ) ) {
                BooklyLib\Utils\Log::tempPut( BooklyLib\Utils\Log::OPTION_OUTLOOK, null, null, $json, 'Outlook push notification' );
                foreach ( $data['value'] as $item ) {
                    if ( isset ( $item['clientState'] ) && preg_match( '/^bookly-(\d+)-.+/', $item['clientState'], $match ) ) {
                        $staff = BooklyLib\Entities\Staff::find( $match[1] );
                        if ( $staff ) {
                            $ms = new Lib\Microsoft\Client();
                            if ( $ms->auth( $staff ) && $ms->data()->subscription->client_state == $item['clientState'] ) {
                                $ms->calendar()->sync();
                            }
                        }
                    }
                }
            }

            wp_send_json_success( null, 202 );
        }

        wp_send_json_error();
    }

    /**
     * Override parent method to not check CSRF token.
     *
     * @param string $action
     * @return bool
     */
    protected static function csrfTokenValid( $action = null )
    {
        return true;
    }
}