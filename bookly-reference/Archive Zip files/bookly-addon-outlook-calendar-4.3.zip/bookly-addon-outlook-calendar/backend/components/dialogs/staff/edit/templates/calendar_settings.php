<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Modules\Settings\Page as SettingsPage;
use Bookly\Lib\Utils\Common;
/** @var Bookly\Lib\Entities\Staff $staff */
?>
<div class="form-group bookly-js-outlook-calendar-row">
    <label><?php esc_html_e( 'Outlook Calendar integration', 'bookly' ) ?></label>
    <div class="form-group border-left ml-4 pl-3">
        <?php if ( isset ( $auth_url ) ) : ?>
            <?php if ( $auth_url ) : ?>
                <a href="<?php echo esc_url( $auth_url ) ?>" class='bookly-ms-signin-button'>
                    <img src="<?php echo plugins_url( 'resources/images/ms-symbollockup_signin_light.png', __DIR__ ) ?>">
                </a>
            <?php else : ?>
                <?php printf( __( 'Please configure Outlook Calendar <a href="%s">settings</a> first', 'bookly' ), Common::escAdminUrl( SettingsPage::pageSlug(), array( 'tab' => 'outlook_calendar' ) ) ) ?>
            <?php endif ?>
        <?php else : ?>
            <?php esc_html_e( 'Connected', 'bookly' ) ?> (
            <span class="custom-control custom-checkbox d-inline-block">
            <input class="custom-control-input" id="outlook_disconnect" type="checkbox" name="outlook_disconnect" value="1">
            <label class="custom-control-label" for="outlook_disconnect"><?php esc_html_e( 'disconnect', 'bookly' ) ?></label>
        </span>
            )
        <?php endif ?>
        <small class="form-text text-muted mb-2"><?php esc_html_e( 'Synchronize staff member appointments with Outlook Calendar.', 'bookly' ) ?></small>
        <?php if ( ! isset ( $auth_url ) ) : ?>
            <div class="form-group bookly-js-outlook-calendars-list">
                <label for="bookly-outlook-calendar-id"><?php esc_html_e( 'Calendar', 'bookly' ) ?></label>
                <select class="form-control custom-select" name="outlook_calendar_id" id="bookly-outlook-calendar-id">
                    <option value=""><?php esc_html_e( '-- Select calendar --', 'bookly' ) ?></option>
                    <?php foreach ( $calendars as $id => $calendar_name ) : ?>
                        <option value="<?php echo esc_attr( $id ) ?>"<?php selected( $calendar_id == $id ) ?>>
                            <?php echo esc_html( $calendar_name ) ?>
                        </option>
                    <?php endforeach ?>
                </select>
                <small class="form-text text-muted"><?php esc_html_e( 'When you connect a calendar all future and past events will be synchronized according to the selected synchronization mode. This may take a few minutes. Please wait.', 'bookly' ) ?></small>
            </div>
        <?php endif ?>
    </div>
</div>