<?php
namespace BooklyOutlookCalendar\Backend\Components\Dialogs\Staff\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;
use Bookly\Lib as BooklyLib;
use Bookly\Lib\Entities\Staff;
use BooklyOutlookCalendar\Lib\Config;
use BooklyOutlookCalendar\Lib\Microsoft;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function editStaffAdvanced( array $data, Staff $staff )
    {
        $auth_url = null;
        $calendars = array();
        $calendar_id = null;
        if ( $staff->getOutlookData() == '' ) {
            if ( Config::getSyncMode() !== null ) {
                $ms = new Microsoft\Client();
                $auth_url = $ms->createAuthUrl( $staff->getId() );
            } else {
                $auth_url = false;
            }
        } else {
            $ms = new Microsoft\Client();
            if ( $ms->auth( $staff, true ) && ( $list = $ms->getCalendarList() ) !== false ) {
                $calendars = $list;
                $calendar_id = $ms->data()->calendar->id;
            } else {
                foreach ( $ms->getErrors() as $error ) {
                    $data['alert']['error'][] = 'Outlook Calendar: ' . $error;
                }
            }
        }

        $data['tpl']['oc'] = compact( 'staff', 'auth_url', 'calendars', 'calendar_id' );

        return $data;
    }

    /**
     * @inheritDoc
     */
    public static function preUpdateStaffAdvanced( array $data, Staff $staff, array $parameters )
    {
        if ( array_key_exists( 'outlook_disconnect', $parameters ) && $parameters['outlook_disconnect'] == 1 ) {
            $ms = new Microsoft\Client();
            if ( $ms->auth( $staff ) ) {
                $ms->calendar()->deleteSubscription( false );
            }
            $staff->setOutlookData( null );
        } elseif ( isset ( $parameters['outlook_calendar_id'] ) ) {
            $calendar_id = str_replace( '/', '', $parameters['outlook_calendar_id'] );
            $ms = new Microsoft\Client();
            $update_data = false;
            if ( $ms->auth( $staff, true ) ) {
                if ( $staff->isArchived() && $parameters['visibility'] != 'archive' && $ms->calendar()->clearDeltaLink()->sync() ) {
                    // Change visibility from archive.
                    $ms->calendar()->createSubscription();
                    $update_data = true;
                } elseif ( ! $staff->isArchived() && $parameters['visibility'] == 'archive' ) {
                    // Change visibility to archive.
                    $ms->calendar()->clearDeltaLink();
                    $update_data = true;
                } elseif ( $calendar_id != $ms->data()->calendar->id ) {
                    // Calendar changed.
                    if ( $staff->isArchived() ) {
                        $data['alerts']['error'][] = __( 'Outlook Calendar', 'bookly' ) . ': ' . __( 'Can\'t change calendar for archived staff', 'bookly' );

                        return $data;
                    } elseif ( $calendar_id != '' ) {
                        if ( ! $ms->validateCalendarId( $calendar_id ) ) {
                            $errors = array();
                            foreach ( $ms->getErrors() as $error ) {
                                $errors[] = __( 'Outlook Calendar', 'bookly' ) . ': ' . $error;
                            }
                            $data['alerts']['error'][] = implode( '<br/>', $errors );

                            return $data;
                        }
                    } else {
                        $calendar_id = null;
                    }
                    $ms->calendar()->clearDeltaLink()->deleteSubscription( false );
                    $ms->data()->calendar->id = $calendar_id;
                    $update_data = true;
                }
                if ( $update_data ) {
                    $staff->setOutlookData( $ms->data()->toJson() );
                }
            }
        }

        return $data;
    }

    /**
     * @inheritDoc
     */
    public static function updateStaffAdvanced( array $data, BooklyLib\Entities\Staff $staff, array $params )
    {
        if ( Config::getSyncMode() == '2-way' ) {
            $ms = new Microsoft\Client();
            if ( $ms->auth( $staff ) ) {
                $ms->calendar()->sync();
                // Register new notification channel.
                if ( ! $ms->calendar()->createSubscription() ) {
                    $data['alerts']['error'][] = 'Outlook Calendar: ' . implode( '<br>', $ms->getErrors() );
                }
            }
        }

        return $data;
    }
}