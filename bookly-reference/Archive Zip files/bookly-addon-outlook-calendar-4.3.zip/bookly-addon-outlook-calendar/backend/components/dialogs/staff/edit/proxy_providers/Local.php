<?php
namespace BooklyOutlookCalendar\Backend\Components\Dialogs\Staff\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

class Local extends Proxy\OutlookCalendar
{
    /**
     * @inheritDoc
     */
    public static function renderCalendarSettings( array $tpl_data )
    {
        self::renderTemplate( 'calendar_settings', $tpl_data['oc'] );
    }
}