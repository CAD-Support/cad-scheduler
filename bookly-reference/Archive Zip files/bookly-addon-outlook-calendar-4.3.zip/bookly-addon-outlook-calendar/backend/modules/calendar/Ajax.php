<?php
namespace BooklyOutlookCalendar\Backend\Modules\Calendar;

use Bookly\Lib as BooklyLib;
use BooklyOutlookCalendar\Lib;

class Ajax extends BooklyLib\Base\Ajax
{
    /**
     * @inheritDoc
     */
    protected static function permissions()
    {
        return array( '_default' => array( 'staff', 'supervisor' ) );
    }

    /**
     * Run incremental synchronization with Outlook Calendar.
     */
    public static function sync()
    {
        if ( Lib\Config::getSyncMode() == '2-way' ) {
            $staff_members = BooklyLib\Utils\Common::isCurrentUserAdmin()
                ? BooklyLib\Entities\Staff::query()->whereNot( 'outlook_data', null )->find()
                : BooklyLib\Entities\Staff::query()->where( 'wp_user_id', get_current_user_id() )->find();
            $ms = new Lib\Microsoft\Client();

            foreach ( $staff_members as $staff ) {
                if ( $ms->auth( $staff ) ) {
                    if ( ! $ms->calendar()->sync() ) {
                        wp_send_json_error( array( 'alert' => array( 'error' => $ms->getErrors() ) ) );
                    }
                }
            }

            wp_send_json_success( array( 'alert' => array( 'success' => array( __( 'Calendars synchronized successfully.', 'bookly' ) ) ) ) );
        }

        wp_send_json_error();
    }
}