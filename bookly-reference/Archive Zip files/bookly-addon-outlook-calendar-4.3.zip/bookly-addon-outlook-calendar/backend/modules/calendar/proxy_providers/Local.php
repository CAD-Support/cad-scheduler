<?php
namespace BooklyOutlookCalendar\Backend\Modules\Calendar\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Modules\Calendar\Proxy;
use BooklyOutlookCalendar\Lib;

class Local extends Proxy\OutlookCalendar
{
    /**
     * @inheritDoc
     */
    public static function renderSyncButton( array $staff_members )
    {
        $show_sync_button = false;
        if ( Lib\Config::getSyncMode() == '2-way' ) {
            /** @var BooklyLib\Entities\Staff $staff */
            foreach ( $staff_members as $staff ) {
                if ( $staff->getOutlookData() != '' ) {
                    $show_sync_button = true;
                    break;
                }
            }
        }

        self::renderTemplate( 'sync_button', compact( 'show_sync_button' ) );
    }
}