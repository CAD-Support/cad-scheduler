<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Buttons;
use Bookly\Backend\Components\Controls\Inputs as ControlsInputs;
use Bookly\Backend\Components\Settings\Inputs;
use Bookly\Backend\Components\Settings\Selects;
use Bookly\Backend\Modules\Settings\Codes;
use Bookly\Backend\Components\Ace;
use BooklyOutlookCalendar\Lib\Microsoft;

?>
<div class="tab-pane" id="bookly_settings_outlook_calendar">
    <form method="post" action="<?php echo esc_url( add_query_arg( 'tab', 'outlook_calendar' ) ) ?>">
        <div class="card-body">
            <div class="form-group">
                <h4><?php esc_html_e( 'Instructions', 'bookly' ) ?></h4>
                <p><?php printf( __( 'To setup %s integration, follow the instruction in <a href="%s" target="_blank">our documentation</a>', 'bookly' ), 'Outlook Calendar', 'https://hub.bookly.pro/go/bookly-settings-outlook-calendar' ) ?></p>
            </div>
            <?php Inputs::renderText( 'bookly_oc_app_id', __( 'Application ID', 'bookly' ), __( 'The Application ID obtained from the Microsoft App Registration Portal.', 'bookly' ) ) ?>
            <?php Inputs::renderText( 'bookly_oc_app_secret', __( 'Application secret', 'bookly' ), __( 'The Application Secret password obtained from the Microsoft App Registration Portal.', 'bookly' ) ) ?>
            <?php Inputs::renderTextCopy( Microsoft\Client::generateRedirectURI(), __( 'Redirect URI', 'bookly' ), __( 'Enter this URL as a Redirect URLs in the Microsoft App Registration Portal.', 'bookly' ) ) ?>
            <?php Selects::renderSingle( 'bookly_oc_sync_mode', __( 'Synchronization mode', 'bookly' ), sprintf( __( 'With "One-way" sync Bookly pushes new appointments and any further changes to %s.', 'bookly' ), __( 'Outlook Calendar', 'bookly' ) ) . ' ' . sprintf( __( 'With "Two-way front-end only" sync Bookly will additionally fetch events from %s and remove corresponding time slots before displaying the Time step of the booking form (this may lead to a delay when users click Next to get to the Time step).', 'bookly' ), __( 'Outlook Calendar', 'bookly' ) ) . ' ' . sprintf( __( 'With "Two-way" sync all bookings created in Bookly Calendar will be automatically copied to %s and vice versa.', 'bookly' ), __( 'Outlook Calendar', 'bookly' ) ), array(
                array( '1-way', __( 'One-way', 'bookly' ) ),
                array( '1.5-way', __( 'Two-way front-end only', 'bookly' ) ),
                array( '2-way', __( 'Two-way', 'bookly' ) ),
            ) ) ?>
            <div class=" border-left ml-4 pl-3">
                <?php Inputs::renderNumbers( array( 'bookly_oc_full_sync_offset_days_before', 'bookly_oc_full_sync_offset_days_after' ), __( 'Sync appointments history (past and future)', 'bookly' ), __( 'Specify how many days of past and future calendar data you wish to sync at the time of initial sync. If you enter 0 in either field, synchronization of past or future events will not be performed', 'bookly' ), array( 0, 0 ) ) ?>
                <?php Selects::renderSingle( 'bookly_oc_full_sync_titles', __( 'Copy Outlook Calendar event titles', 'bookly' ), __( 'If enabled then titles of Outlook Calendar events will be copied to Bookly appointments. If disabled, a standard title "Outlook Calendar event" will be used.', 'bookly' ) ) ?>
                <?php Selects::renderSingle( 'bookly_oc_limit_events', __( 'Limit number of fetched events', 'bookly' ), __( 'If there is a lot of events in Outlook Calendar sometimes this leads to a lack of memory in PHP when Bookly tries to fetch all events. You can limit the number of fetched events here.', 'bookly' ), $fetch_limits ) ?>
            </div>
            <?php Inputs::renderText( 'bookly_oc_event_title', __( 'Template for event title', 'bookly' ), __( 'Configure what information should be placed in the title of Outlook Calendar event.', 'bookly' ) . ' ' . sprintf( __('Available codes are %s and %s.', 'bookly' ), '{service_name}, {category_name}, {staff_name}, {client_names}', '{client_phones}' ) ) ?>
            <div class="form-group">
                <label for="bookly_oc_event_description"><?php esc_html_e( 'Template for event description', 'bookly' ) ?></label>
                <?php Ace\Editor::render( 'bookly-settings-outlook-calendar', 'bookly_oc_event_description', Codes::getJson( 'outlook_calendar' ), get_option( 'bookly_oc_event_description', '' ) ) ?>
                <input type="hidden" name="bookly_oc_event_description" value="<?php echo esc_attr( get_option( 'bookly_oc_event_description', '' ) ) ?>">
            </div>
        </div>

        <div class="card-footer bg-transparent d-flex justify-content-end">
            <?php ControlsInputs::renderCsrf() ?>
            <?php Buttons::renderSubmit() ?>
            <?php Buttons::renderReset( null, 'ml-2' ) ?>
        </div>
    </form>
</div>