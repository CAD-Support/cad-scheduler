<?php
namespace BooklyOutlookCalendar\Lib;

abstract class Config
{
    /**
     * Get Application ID.
     *
     * @return string|false
     */
    public static function getAppId()
    {
        return get_option( 'bookly_oc_app_id' );
    }

    /**
     * Get Application Secret password.
     *
     * @return string|false
     */
    public static function getAppSecret()
    {
        return get_option( 'bookly_oc_app_secret' );
    }

    /**
     * Get Outlook Calendar synchronization mode (null means Outlook Calendar integration is not configured).
     *
     * @return string|null  1-way, 1.5-way, 2-way
     */
    public static function getSyncMode()
    {
        if ( get_option( 'bookly_oc_app_id' ) == '' ) {
            return null;
        }

        return get_option( 'bookly_oc_sync_mode', '1.5-way' );
    }


}