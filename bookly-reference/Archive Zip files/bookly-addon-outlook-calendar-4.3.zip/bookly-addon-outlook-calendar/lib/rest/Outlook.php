<?php
namespace BooklyOutlookCalendar\Lib\Rest;

use BooklyOutlookCalendar\Lib\Microsoft;
use Bookly\Backend\Modules\Staff\Page as StaffPage;
use Bookly\Lib as BooklyLib;

class Outlook
{
    public static function init()
    {
        add_action( 'rest_api_init', function() {
            register_rest_route( 'bookly', Outlook::getAuthRedirectURI(), array(
                'methods' => 'GET',
                'callback' => array( __CLASS__, 'handleOAuthCallback' ),
                'permission_callback' => '__return_true',
            ) );
        } );
    }

    /**
     * Handle OAuth callback from Microsoft Azure.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public static function handleOAuthCallback( $request )
    {
        $code = $request->get_param( 'code' );
        $state = $request->get_param( 'state' );

        if ( ! $code || ! $state ) {
            return new \WP_Error( 'missing_params', 'Missing code or state parameter.', array( 'status' => 400 ) );
        }

        $client = new Microsoft\Client();
        $staff_id = $client->extractStaffIdFromState( $state );

        if ( ! $staff_id ) {
            return new \WP_Error( 'invalid_state', 'Invalid state parameter.', array( 'status' => 400 ) );
        }

        $token = $client->exchangeCodeForAccessToken( $code );
        if ( $token ) {
            $data = new Microsoft\Data\Holder();
            $data->token = $token;
            $staff = new BooklyLib\Entities\Staff();
            $staff->load( $staff_id );
            $staff
                ->setOutlookData( $data->toJson() )
                ->save();
        }

        BooklyLib\Utils\Common::redirect( admin_url( 'admin.php?page=' . StaffPage::pageSlug() . '&tab=advanced&staff_id=' . $staff_id ) );
    }

    public static function getAuthRedirectURI()
    {
        return '/calendars/outlook';
    }
}
