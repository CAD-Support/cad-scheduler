<?php
namespace BooklyOutlookCalendar\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;
use BooklyOutlookCalendar\Lib;

class Shared extends BooklyLib\Proxy\Shared
{
    /**
     * Add the Outlook Calendar tab to the Settings submenu in the fullscreen header sidebar.
     *
     * @param array $submenus
     * @return array
     */
    public static function buildHeaderSubmenus( $submenus )
    {
        if ( isset( $submenus['bookly-settings'] ) ) {
            $submenus['bookly-settings'][] = array( 'label' => __( 'Outlook Calendar', 'bookly' ), 'tab' => 'outlook_calendar', 'badge' => '' );
        }

        return $submenus;
    }

    /**
     * @inheritDoc
     */
    public static function doDailyRoutine()
    {
        if ( Lib\Config::getSyncMode() == '2-way' ) {
            // Renew expired notification subscriptions.
            $ms = new Lib\Microsoft\Client();
            $deadline = date_create( '+1 day' );
            foreach ( BooklyLib\Entities\Staff::query()->whereNot( 'outlook_data', null )->find() as $staff ) {
                if ( $ms->auth( $staff ) && $ms->data()->subscription->id != '' ) {
                    if ( date_create( $ms->data()->subscription->expiration_date_time ) < $deadline ) {
                        $ms->calendar()->renewSubscription();
                    }
                }
            }
        }
    }
}