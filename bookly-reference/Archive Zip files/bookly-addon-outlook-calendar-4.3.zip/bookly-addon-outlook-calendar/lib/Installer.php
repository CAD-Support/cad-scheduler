<?php
namespace BooklyOutlookCalendar\Lib;

use Bookly\Lib as BooklyLib;

class Installer extends Base\Installer
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->options = array(
            'bookly_oc_app_id' => '',
            'bookly_oc_app_secret' => '',
            'bookly_oc_event_title' => '{service_name}',
            'bookly_oc_sync_mode' => '1.5-way',
            'bookly_oc_limit_events' => '50',
            'bookly_oc_full_sync_offset_days_before' => '0',
            'bookly_oc_full_sync_offset_days_after' => '365',
            'bookly_oc_full_sync_titles' => '1',
            'bookly_oc_event_description' => '{#each participants as participant}' . __( 'Name', 'bookly' ) . ': {participant.client_name}' . PHP_EOL . __( 'Email', 'bookly' ) . ': {participant.client_email}' . PHP_EOL . __( 'Phone', 'bookly' ) . ': {participant.client_phone}' . PHP_EOL . '{/each}',
            'bookly_temporary_logs_outlook' => '0',
        );
    }
}