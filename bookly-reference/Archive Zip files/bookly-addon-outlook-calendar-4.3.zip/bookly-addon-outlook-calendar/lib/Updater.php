<?php
namespace BooklyOutlookCalendar\Lib;

use Bookly\Lib as BooklyLib;

class Updater extends BooklyLib\Base\Updater
{
    public function update_3_8()
    {
        $new_pc_key = 'bookly_outlook_calendar_purchase_code';
        $old_pc_key = 'bookly_outlook_calendar_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_3_5()
    {
        add_option( 'bookly_temporary_logs_outlook', '0' );
    }

    public function update_2_1()
    {
        $bookly_oc_event_appointment_info = get_option( 'bookly_oc_event_appointment_info' );
        if ( $bookly_oc_event_appointment_info !== false ) {
            if ( $bookly_oc_event_appointment_info !== '' ) {
                $bookly_oc_event_appointment_info .= PHP_EOL;
            }
            $bookly_oc_event_client_info = get_option( 'bookly_oc_event_client_info', '' );
            $replace = array(
                '{appointment_notes}' => '{participant.appointment_notes}',
                '{client_email}' => '{participant.client_email}',
                '{client_first_name}' => '{participant.client_first_name}',
                '{client_last_name}' => '{participant.client_last_name}',
                '{client_name}' => '{participant.client_name}',
                '{client_phone}' => '{participant.client_phone}',
                '{payment_status}' => '{participant.payment_status}',
                '{payment_type}' => '{participant.payment_type}',
                '{status}' => '{participant.status}',
                '{total_price}' => '{participant.total_price}',
                '{client_address}' => '{participant.client_address}',
                '{custom_fields}' => '{participant.custom_fields}',
                '{number_of_persons}' => '{participant.number_of_persons}',
                '{extras}' => '{participant.extras}',
                '{extras_total_price}' => '{participant.extras_total_price}',
            );
            $bookly_oc_event_client_info = '{#each participants as participant}' . PHP_EOL . strtr( $bookly_oc_event_client_info, $replace ) . PHP_EOL . '{/each}';

            add_option( 'bookly_oc_event_description', $bookly_oc_event_appointment_info . $bookly_oc_event_client_info );
            delete_option( 'bookly_oc_event_appointment_info' );
            delete_option( 'bookly_oc_event_client_info' );
        }
    }
    
    public function update_1_6()
    {
        $this->renameOptions( array( 'bookly_oc_full_sync_offset_days' => 'bookly_oc_full_sync_offset_days_before' ) );
        add_option( 'bookly_oc_full_sync_offset_days_after', 365 );
    }
}