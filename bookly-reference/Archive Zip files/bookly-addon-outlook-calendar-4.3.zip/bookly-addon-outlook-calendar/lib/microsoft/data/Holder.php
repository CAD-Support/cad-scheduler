<?php
namespace BooklyOutlookCalendar\Lib\Microsoft\Data;

class Holder extends Base
{
    /** @var Token */
    public $token;

    /** @var Calendar */
    public $calendar;

    /** @var Subscription */
    public $subscription;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->token        = new Token();
        $this->calendar     = new Calendar();
        $this->subscription = new Subscription();
    }
}