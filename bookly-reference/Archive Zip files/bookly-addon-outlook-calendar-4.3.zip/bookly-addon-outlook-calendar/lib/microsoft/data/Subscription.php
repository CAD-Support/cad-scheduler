<?php
namespace BooklyOutlookCalendar\Lib\Microsoft\Data;

class Subscription extends Base
{
    /** @var string */
    public $id;

    /** @var string */
    public $expiration_date_time;

    /** @var string */
    public $client_state;
}