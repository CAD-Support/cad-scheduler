<?php
namespace BooklyOutlookCalendar\Lib\Microsoft\Data;

abstract class Base
{
    /**
     * Set data from array.
     *
     * @param array $data
     * @return $this
     */
    protected function _setData( array $data )
    {
        foreach ( $data as $key => $value ) {
            if ( ! property_exists( $this, $key ) ) {
                continue;
            }
            if ( is_array( $value ) ) {
                $this->{$key}->_setData( $value );
            } else {
                $this->{$key} = $value;
            }
        }

        return $this;
    }

    /**
     * Create from JSON string.
     *
     * @param string $json
     * @return static
     */
    public static function fromJson( $json )
    {
        $auth_data = new static();

        return $auth_data->_setData( json_decode( $json, true ) );
    }

    /**
     * Convert to JSON string.
     *
     * @return string
     */
    public function toJson()
    {
        return json_encode( $this );
    }
}