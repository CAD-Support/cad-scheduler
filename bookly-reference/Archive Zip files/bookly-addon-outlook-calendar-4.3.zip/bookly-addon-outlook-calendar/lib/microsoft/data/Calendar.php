<?php
namespace BooklyOutlookCalendar\Lib\Microsoft\Data;

class Calendar extends Base
{
    /** @var string */
    public $id;

    /** @var string */
    public $delta_link;
}