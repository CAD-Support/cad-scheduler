<?php
namespace BooklyOutlookCalendar\Lib\Microsoft\Data;

class Token extends Base
{
    /** @var string */
    public $token_type;

    /** @var string */
    public $scope;

    /** @var string */
    public $expires_in;

    /** @var string */
    public $ext_expires_in;

    /** @var string */
    public $access_token;

    /** @var string */
    public $refresh_token;

    /** @var int */
    public $created;
}