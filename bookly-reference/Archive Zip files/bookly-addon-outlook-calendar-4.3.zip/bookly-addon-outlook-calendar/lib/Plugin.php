<?php
namespace BooklyOutlookCalendar\Lib;

use Bookly\Lib as BooklyLib;
use BooklyOutlookCalendar\Frontend;
use BooklyOutlookCalendar\Backend;

abstract class Plugin extends BooklyLib\Base\Plugin
{
    protected static $prefix;
    protected static $title;
    protected static $version;
    protected static $slug;
    protected static $directory;
    protected static $main_file;
    protected static $basename;
    protected static $text_domain;
    protected static $root_namespace;
    protected static $embedded;

    /**
     * @inheritDoc
     */
    protected static function init()
    {
        // Register proxy methods.
        Backend\Components\Dialogs\Staff\Edit\ProxyProviders\Local::init();
        Backend\Components\Dialogs\Staff\Edit\ProxyProviders\Shared::init();
        Backend\Modules\Calendar\ProxyProviders\Local::init();
        Backend\Modules\Settings\ProxyProviders\Shared::init();
        ProxyProviders\Local::init();
        ProxyProviders\Shared::init();
    }

    /**
     * @inheritDoc
     */
    protected static function registerAjax()
    {
        Backend\Modules\Calendar\Ajax::init();
        Frontend\Modules\Outlook\Ajax::init();
    }

    /**
     * @inheritDoc
     */
    public static function registerHooks()
    {
        parent::registerHooks();

        Rest\Outlook::init();
    }
}
