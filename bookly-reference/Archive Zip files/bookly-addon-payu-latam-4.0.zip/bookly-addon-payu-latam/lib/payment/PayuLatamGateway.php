<?php
namespace BooklyPayuLatam\Lib\Payment;

use Bookly\Lib as BooklyLib;

class PayuLatamGateway extends BooklyLib\Base\Gateway
{
    protected $type = BooklyLib\Entities\Payment::TYPE_PAYULATAM;

    CONST SANDBOX_API_KEY = '4Vj8eK4rloUd272L48hsrarnUA';
    CONST SANDBOX_API_MERCHANT_ID = '508029';
    const SANDBOX_API_ACCOUNT_ID = '512326';
    CONST TRANSACTION_STATE_APPROVED = 4;
    CONST TRANSACTION_STATE_PENDING  = 7;

    /**
     * @inerhitDoc
     */
    protected function getCheckoutUrl( array $intent_data )
    {
        return $intent_data['target_url'];
    }

    /**
     * @inerhitDoc
     */
    protected function getInternalMetaData()
    {
        return array();
    }

    /**
     * @inerhitDoc
     */
    protected function createGatewayIntent()
    {
        if ( $this->isSandbox() ) {
            $api_key = self::SANDBOX_API_KEY;
            $merchant_id = self::SANDBOX_API_MERCHANT_ID;
            $account_id = self::SANDBOX_API_ACCOUNT_ID;
            $url = 'https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/';
            $test = 1;
        } else {
            $api_key = get_option( 'bookly_payu_latam_api_key' );
            $merchant_id = get_option( 'bookly_payu_latam_api_merchant_id' );
            $account_id = get_option( 'bookly_payu_latam_api_account_id' );
            $url = 'https://checkout.payulatam.com/ppp-web-gateway-payu/';
            $test = '0';
        }
        $reference_code = wp_generate_password( 16, false );
        $amount = number_format( $this->getGatewayAmount(), '2', '.', '' );

        $data = array(
            'accountId' => $account_id,
            'merchantId' => $merchant_id,
            'amount' => $amount,
            'buyerEmail' => $this->request->getUserData()->getEmail(),
            'buyerFullName' => $this->request->getUserData()->getFullName(),
            'confirmationUrl' => $this->getWebHookUrl(),
            'currency' => BooklyLib\Config::getCurrency(),
            'description' => $this->request->getUserData()->cart->getItemsTitle( 127 ),
            'discount' => '0',
            'referenceCode' => $reference_code,
            'responseUrl' => $this->getResponseUrl( self::EVENT_RETRIEVE ),
            'shipmentValue' => '0.00',
            'signature' => md5( implode( '~', array( $api_key, $merchant_id, $reference_code, $amount, BooklyLib\Config::getCurrency() ) ) ),
            'tax' => $this->getGatewayTax(),
            'taxReturnBase' => '0',
            'test' => $test
        );
        $response = wp_remote_post(
            $url,
            array(
                'timeout' => 25,
                'redirection' => false,
                'sslverify' => false,
                'body' => $data,
            ) );

        $headers = wp_remote_retrieve_headers( $response )->getAll();
        if ( array_key_exists( 'location', $headers ) ) {
            return array(
                'target_url' => $headers['location'],
            );
        }

        throw new \Exception( 'Missing header location' );
    }

    /**
     * @inerhitDoc
     */
    public function retrieveStatus()
    {
        $is_webhook_request = false;
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
            // webhook
            $received = (float) $this->request->get( 'value' );
            $transaction_state = $this->request->get( 'state_pol' );
            $signature = $this->request->get( 'sign' );
            $reference_code = $this->request->get( 'reference_sale' );
            if ( $reference_code === null ) {
                // A case when a customer closed the modal window
                // with the payment system themselves.
                return self::STATUS_PROCESSING;
            }
            $this->getPayment()->setRefId( $this->request->get( 'transaction_id' ) );
            $is_webhook_request = true;
        } else {
            // Back from checkout
            $received = (float) $this->request->get( 'TX_VALUE' );
            $transaction_state = $this->request->get( 'transactionState' );
            $signature = $this->request->get( 'signature' );
            $reference_code = $this->request->get( 'referenceCode' );
            $this->getPayment()->setRefId( $this->request->get( 'transactionId' ) );
        }

        if ( $this->validatePaymentData( $received, $this->request->get( 'currency' ) ) ) {
            if ( $this->isSandbox() ) {
                $api_key = self::SANDBOX_API_KEY;
                $merchant_id = self::SANDBOX_API_MERCHANT_ID;
            } else {
                $api_key = get_option( 'bookly_payu_latam_api_key' );
                $merchant_id = get_option( 'bookly_payu_latam_api_merchant_id' );
            }

            $TX_VALUE = number_format( round( $received, 1, PHP_ROUND_HALF_EVEN ), 1, '.', '' );
            if ( $signature == md5( implode( '~', array( $api_key, $merchant_id, $reference_code, $TX_VALUE, BooklyLib\Config::getCurrency(), $transaction_state ) ) ) ) {
                switch ( $transaction_state ) {
                    case self::TRANSACTION_STATE_APPROVED:
                        return self::STATUS_COMPLETED;
                    case self::TRANSACTION_STATE_PENDING:
                        return self::STATUS_PROCESSING;
                }
            }
        }

        // Status cancelled, open or failed
        return $is_webhook_request
            ? self::STATUS_PROCESSING
            : self::STATUS_FAILED;
    }

    private function isSandbox()
    {
        return  get_option( 'bookly_payu_latam_sandbox' ) == 1;
    }
}