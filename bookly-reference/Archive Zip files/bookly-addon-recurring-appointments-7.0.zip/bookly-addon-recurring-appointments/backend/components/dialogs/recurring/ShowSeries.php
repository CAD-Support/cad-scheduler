<?php
namespace BooklyRecurringAppointments\Backend\Components\Dialogs\Recurring;

use Bookly\Lib as BooklyLib;

class ShowSeries extends BooklyLib\Base\Component
{
    /**
     * Render show series dialog.
     */
    public static function render()
    {
        self::enqueueScripts( array(
            'module' => array( 'js/series-dialog.js' => array( 'bookly-backend-globals', 'bookly-queue-dialog.js' ), )
        ) );

        wp_localize_script( 'bookly-series-dialog.js', 'BooklyL10nSeriesDialog', array(
            'csrf_token' => BooklyLib\Utils\Common::getCsrfToken(),
            'moment_format_date' => BooklyLib\Utils\DateTime::convertFormat( 'date', BooklyLib\Utils\DateTime::FORMAT_MOMENT_JS ),
            'moment_format_time' => BooklyLib\Utils\DateTime::convertFormat( 'time', BooklyLib\Utils\DateTime::FORMAT_MOMENT_JS ),
            'l10n' => array(
                'recurring_appointments' => __( 'Recurring appointments', 'bookly' ),
                'na' => __( 'N/A', 'bookly' ),
                'close' => __( 'Close', 'bookly' ),
                'edit' => __( 'Edit', 'bookly' ),
                'delete_series' => __( 'Delete series', 'bookly' ),
                'confirm_delete' => __( 'Delete', 'bookly' ),
                'cancel' => __( 'Cancel', 'bookly' ),
                'send_notifications' => __( 'Send notifications', 'bookly' ),
                'cancellation_reason' => __( 'Cancellation reason (optional)', 'bookly' ),
                'delete_series_confirm_text' => __( 'This will permanently delete all appointments in this series. This action cannot be undone.', 'bookly' ),
            ),
        ) );
    }
}