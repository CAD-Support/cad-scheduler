<?php
namespace BooklyRecurringAppointments\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Lib\Entities\Notification;

class Shared extends BooklyLib\Proxy\Shared
{
    /**
     * Add the Recurring Appointments tab to the Settings submenu in the fullscreen header sidebar.
     *
     * @param array $submenus
     * @return array
     */
    public static function buildHeaderSubmenus( $submenus )
    {
        if ( isset( $submenus['bookly-settings'] ) ) {
            $submenus['bookly-settings'][] = array( 'label' => __( 'Recurring Appointments', 'bookly' ), 'tab' => 'recurring_appointments', 'badge' => '' );
        }

        return $submenus;
    }

    /**
     * @inheritDoc
     */
    public static function prepareNotificationTitles( array $titles )
    {
        $titles[ Notification::TYPE_NEW_BOOKING_RECURRING ]                         = __( 'New recurring booking notification', 'bookly' );
        $titles[ Notification::TYPE_CUSTOMER_APPOINTMENT_STATUS_CHANGED_RECURRING ] = __( 'Notification about recurring appointment status changes', 'bookly' );

        return $titles;
    }

    /**
     * @inheritDoc
     */
    public static function prepareNotificationTypes( array $types, $gateway )
    {
        $types[] = Notification::TYPE_NEW_BOOKING_RECURRING;
        $types[] = Notification::TYPE_CUSTOMER_APPOINTMENT_STATUS_CHANGED_RECURRING;

        return $types;
    }

}