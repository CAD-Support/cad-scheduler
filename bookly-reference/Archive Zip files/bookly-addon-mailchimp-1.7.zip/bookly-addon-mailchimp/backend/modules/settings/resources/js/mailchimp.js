jQuery(function ($) {
    'use strict';

    let $form = $('#bookly_settings_mailchimp form'),
        $template = $('#bookly-mailchimp-field-template .form-group'),
        $addField = $('#bookly-mailchimp-add-field', $form),
        $fields = $('#bookly-mailchimp-fields', $form),
        $resetForm = $('.card-footer button[type=reset]', $form)
    ;

    function addField(name, value) {
        let $field = $template.clone()
        $('[name="bookly_mailchimp_field_name[]"]', $field).val(name);
        $('[name="bookly_mailchimp_field_value[]"]', $field).val(value);
        $fields.append($field);
    }

    for (var field in BooklyL10nMailchimp.fields) {
        addField(field, BooklyL10nMailchimp.fields[field]);
    }

    $addField
        .on('click', function () {
            addField('', '');
        });

    $fields
        .on('click', '.bookly-js-delete-field', function (e) {
            e.preventDefault();
            let $row = $(this).closest('.form-group');

            booklyModal(BooklyL10nMailchimp.delete, BooklyL10nMailchimp.are_you_sure, BooklyL10nMailchimp.cancel, BooklyL10nMailchimp.delete)
                .on('bs.click.main.button', function (event, modal) {
                    $row.remove();
                    modal.booklyModal('hide');
                });
        });

    $resetForm
        .on('click', function () {
            $fields.html('');
            setTimeout(function () {
                for (var field in BooklyL10nMailchimp.fields) {
                    addField(field, BooklyL10nMailchimp.fields[field]);
                }
            }, 0);
        });
});