<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Buttons;
use Bookly\Backend\Components\Controls\Inputs as ControlsInputs;
use Bookly\Backend\Components\Settings\Inputs;
use Bookly\Backend\Components\Settings\Selects;
use Bookly\Backend\Components\Controls\Container;
/** @var \BooklyMailchimp\Backend\Modules\Settings\ProxyProviders\Local $self */
?>
<div class="tab-pane" id="bookly_settings_mailchimp">
    <form method="post" action="<?php echo esc_url( add_query_arg( 'tab', 'mailchimp' ) ) ?>">
        <div class="card-body">
            <div class="form-group">
                <h4><?php esc_html_e( 'Instructions', 'bookly' ) ?></h4>
                <p><?php _e( 'To find your <b>API Key</b> and <b>Server</b> parameter, do the following:', 'bookly' ) ?></p>
                <ol>
                    <li><?php printf( __( 'Navigate to the <a href="%s" target="_blank">API Keys section</a> of your Mailchimp account.', 'bookly' ), 'https://admin.mailchimp.com/account/api/' ) ?></li>
                    <li><?php esc_html_e( 'If you already have an API key listed and you\'d like to use it for your application, simply copy it.', 'bookly' ) ?></li>
                    <li><?php _e( 'Otherwise, click <b>Create Key</b> and give it a descriptive name that will remind you which application it\'s used for.', 'bookly' ) ?></li>
                </ol>
            </div>
            <?php Inputs::renderText( 'bookly_mailchimp_api_key', __( 'API Key', 'bookly' ), __( 'The API Key obtained from your Mailchimp account', 'bookly' ) ) ?>
            <?php Inputs::renderText( 'bookly_mailchimp_server', __( 'Server', 'bookly' ), __( 'To find the value, log into Mailchimp account and look at the URL in your browser. You\'ll see something like https://us19.admin.mailchimp.com/; the us19 part is the server prefix. Note that your specific value may be different', 'bookly' ) ) ?>
            <?php Selects::renderSingle( 'bookly_mailchimp_update_mode', __( 'Update mode', 'bookly' ), __( 'Override customer\'s data in Mailchimp if email address matches the existing one. If you select "Override", then information about existing user will be overrided. If you select "Don\'t override", then information about existing user will remain unchanged', 'bookly' ), array( array( 'override', __( 'Override', 'bookly' ) ), array( 'dont_override', __( 'Don\'t override', 'bookly' ) ) ) ) ?>
            <?php Selects::renderSingle( 'bookly_mailchimp_default_status', __( 'Default status', 'bookly' ), __( 'Default status of new user according to Mailchimp statuses', 'bookly' ), array( array( 'subscribed', __( 'Subscribed', 'bookly' ) ), array( 'unsubscribed', __( 'Unsubscribed', 'bookly' ) ), array( 'pending', __( 'Pending', 'bookly' ) ), array( 'cleaned', __( 'Cleaned', 'bookly' ) ), array( 'transactional', __( 'Transactional', 'bookly' ) ) ) ) ?>
            <?php Inputs::renderText( 'bookly_mailchimp_audience_id', __( 'Audience ID', 'bookly' ), __( 'ID of audience can be found in Settings > Audience name and campaign defaults of interested audience', 'bookly' ) ) ?>
            <div class="form-group">
                <h4><?php esc_html_e( 'Fields matching', 'bookly' ) ?></h4>
                <p><?php esc_html_e( 'Enter the tags of the fields in your Mailchimp audience settings in accordance with Bookly data.', 'bookly' ) ?> <?php printf( __( 'You can find these tags in <b>Audience settings > Audience fields and %s tags</b> in your Mailchimp account', 'bookly' ), '*|MERGE|*' ) ?></p>
                <div class="form-group border-left mt-3 ml-4 pl-3">
                    <div class="form-row col flex-fill px-0">
                        <div class="col-6 mr-n3">
                            <label><?php esc_html_e( 'Tag', 'bookly' ) ?></label>
                        </div>
                        <div class="col-6">
                            <label><?php esc_html_e( 'Value', 'bookly' ) ?></label>
                        </div>
                    </div>
                    <div id="bookly-mailchimp-fields"></div>
                    <?php Container::renderHeader( __( 'Codes', 'bookly' ), 'bookly-mailchimp-codes', false ) ?>
                    <?php $self::renderCodes() ?>
                    <?php Container::renderFooter() ?>
                    <?php Buttons::renderAdd( 'bookly-mailchimp-add-field', null, __( 'Add field', 'bookly' ) ) ?>
                </div>
            </div>
            <?php Selects::renderSingle( 'bookly_mailchimp_delete_customer_cascade', __( 'Remove a subscriber from mailing list when customer is deleted in Bookly', 'bookly' ) ) ?>
        </div>
        <div class="card-footer bg-transparent d-flex justify-content-end">
            <?php ControlsInputs::renderCsrf() ?>
            <?php Buttons::renderSubmit() ?>
            <?php Buttons::renderReset( null, 'ml-2' ) ?>
        </div>
    </form>

    <div id="bookly-mailchimp-field-template" style="display: none;">
        <div class="form-group">
            <div class="d-flex">
                <div class="form-row col flex-fill px-0">
                    <div class="col-6">
                        <input type="text" class="form-control" name="bookly_mailchimp_field_name[]" value=""/>
                    </div>
                    <div class="col-6">
                        <input type="text" class="form-control" name="bookly_mailchimp_field_value[]" value=""/>
                    </div>
                </div>
                <div class="d-flex col pr-1">
                    <button class="btn align-self-end bookly-js-delete-field px-1" title="<?php esc_attr_e( 'Delete', 'bookly' ) ?>"><i class="far fa-fw fa-trash-alt text-danger"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>