<?php
namespace BooklyMailchimp\Backend\Modules\Settings\ProxyProviders;

use Bookly\Backend\Modules\Settings\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function enqueueAssets()
    {
        self::enqueueScripts( array(
            'module' => array( 'js/mailchimp.js' => array( 'bookly-backend-globals' ) ),
        ) );

        wp_localize_script( 'bookly-mailchimp.js', 'BooklyL10nMailchimp', array(
            'fields' => get_option( 'bookly_mailchimp_fields' ) ?: array(),
            'are_you_sure' => __( 'Are you sure?', 'bookly' ),
            'delete' => __( 'Delete', 'bookly' ),
            'cancel' => __( 'Cancel', 'bookly' ),
        ) );
    }

    /**
     * @inheritDoc
     */
    public static function saveSettings( array $alert, $tab, array $params )
    {
        if ( $tab == 'mailchimp' ) {
            $options = array(
                'bookly_mailchimp_api_key',
                'bookly_mailchimp_server',
                'bookly_mailchimp_update_mode',
                'bookly_mailchimp_default_status',
                'bookly_mailchimp_audience_id',
                'bookly_mailchimp_delete_customer_cascade',
                'bookly_mailchimp_fields',
            );
            $params['bookly_mailchimp_fields'] = array();
            if ( array_key_exists( 'bookly_mailchimp_field_name', $params ) ) {
                foreach ( $params['bookly_mailchimp_field_name'] as $id => $value ) {
                    $params['bookly_mailchimp_fields'][ $value ] = $params['bookly_mailchimp_field_value'][ $id ];
                }
            }

            foreach ( $options as $option_name ) {
                if ( array_key_exists( $option_name, $params ) ) {
                    update_option( $option_name, $params[ $option_name ] );
                }
            }
            $alert['success'][] = __( 'Settings saved.', 'bookly' );
        }

        return $alert;
    }
}