<?php
namespace BooklyMailchimp\Backend\Modules\Settings\ProxyProviders;

use Bookly\Backend\Components\Settings\Menu;
use Bookly\Backend\Modules\Settings\Proxy;
use Bookly\Lib as BooklyLib;

class Local extends Proxy\Mailchimp
{
    /**
     * @inheritDoc
     */
    public static function renderMenuItem()
    {
        Menu::renderItem( 'Mailchimp', 'mailchimp' );
    }

    /**
     * @inheritDoc
     */
    public static function renderTab()
    {
        self::renderTemplate( 'mailchimp_tab' );
    }

    /**
     * Render codes for Fields matching
     *
     * @return void
     */
    public static function renderCodes()
    {
        $codes = array(
            'client_address' => __( 'Address of client', 'bookly' ),
            'client_birthday' => __( 'Client birthday', 'bookly' ),
            'client_email' => __( 'Email of client', 'bookly' ),
            'client_first_name' => __( 'First name of client', 'bookly' ),
            'client_last_name' => __( 'Last name of client', 'bookly' ),
            'client_name' => __( 'Full name of client', 'bookly' ),
            'client_note' => __( 'Note of client', 'bookly' ),
            'client_phone' => __( 'Phone of client', 'bookly' ),
        );

        $tbody = '';
        foreach ( $codes as $key => $description ) {
            $tbody .= sprintf(
                '<tr><td class="p-0"><input value="{%s}" class="border-0 bookly-outline-0" readonly="readonly" onclick="this.select()" /> &ndash; %s</td></tr>',
                $key,
                esc_html( $description )
            );
        }

        echo sprintf( '<table class="bookly-js-codes"><tbody>%s</tbody></table>', $tbody );
    }

}