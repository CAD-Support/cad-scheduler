<?php
namespace BooklyMailchimp\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;

class Shared extends BooklyLib\Proxy\Shared
{
    /**
     * Add the Mailchimp tab to the Settings submenu in the fullscreen header sidebar.
     *
     * @param array $submenus
     * @return array
     */
    public static function buildHeaderSubmenus( $submenus )
    {
        if ( isset( $submenus['bookly-settings'] ) ) {
            $submenus['bookly-settings'][] = array( 'label' => 'Mailchimp', 'tab' => 'mailchimp', 'badge' => '' );
        }

        return $submenus;
    }
}
