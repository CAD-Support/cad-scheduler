<?php
namespace BooklyMailchimp\Lib;

use Bookly\Lib\Base;
use BooklyMailchimp\Backend;

abstract class Plugin extends Base\Plugin
{
    protected static $prefix;
    protected static $title;
    protected static $version;
    protected static $slug;
    protected static $directory;
    protected static $main_file;
    protected static $basename;
    protected static $text_domain;
    protected static $root_namespace;
    protected static $embedded;

    /**
     * @inheritDoc
     */
    protected static function init()
    {
        // Init proxy.
        Backend\Modules\Settings\ProxyProviders\Local::init();
        Backend\Modules\Settings\ProxyProviders\Shared::init();
        Entities\ProxyProviders\Shared::init();
        ProxyProviders\Shared::init();
    }

}