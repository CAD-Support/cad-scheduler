<?php
namespace BooklyMailchimp\Lib;

use Bookly\Lib as BooklyLib;

class Installer extends Base\Installer
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->options = array(
            'bookly_mailchimp_api_key' => '',
            'bookly_mailchimp_server' => '',
            'bookly_mailchimp_update_mode' => 'override',
            'bookly_mailchimp_default_status' => 'subscribed',
            'bookly_mailchimp_audience_id' => '',
            'bookly_mailchimp_delete_customer_cascade' => '0',
            'bookly_mailchimp_fields' => array( 'FNAME' => '{client_first_name}', 'LNAME' => '{client_last_name}', ),
        );
    }

}