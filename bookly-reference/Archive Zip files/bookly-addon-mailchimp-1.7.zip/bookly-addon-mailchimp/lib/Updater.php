<?php
namespace BooklyMailchimp\Lib;

use Bookly\Lib;

class Updater extends Lib\Base\Updater
{
    public function update_1_6()
    {
        $new_pc_key = 'bookly_mailchimp_purchase_code';
        $old_pc_key = 'bookly_mailchimp_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_1_2()
    {
        $FNAME = get_option( 'bookly_mailchimp_fields_fname', '{client_first_name}' );
        $LNAME = get_option( 'bookly_mailchimp_fields_lname', '{client_last_name}' );

        add_option( 'bookly_mailchimp_fields', compact( 'FNAME', 'LNAME' ) );
        delete_option( 'bookly_mailchimp_fields_fname' );
        delete_option( 'bookly_mailchimp_fields_lname' );
    }

    public function update_1_1()
    {
        add_option( 'bookly_mailchimp_delete_customer_cascade', '0' );
    }
}