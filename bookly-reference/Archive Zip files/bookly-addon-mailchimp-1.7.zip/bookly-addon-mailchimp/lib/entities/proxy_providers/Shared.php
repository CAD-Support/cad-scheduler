<?php
namespace BooklyMailchimp\Lib\Entities\ProxyProviders;

use Bookly\Lib;
use Bookly\Lib\Entities\Proxy;
use BooklyMailchimp\Lib\Mailchimp\ApiClient;
use BooklyMailchimp\Lib\Mailchimp\Member;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function postSaveCustomer( Lib\Entities\Customer $customer )
    {
        if ( get_option( 'bookly_mailchimp_api_key' ) != ''
            && get_option( 'bookly_mailchimp_server' ) != ''
            && get_option( 'bookly_mailchimp_audience_id' ) != ''
        ) {
            $mailchimp = new ApiClient( get_option( 'bookly_mailchimp_api_key' ), get_option( 'bookly_mailchimp_server' ) );
            $member = new Member( $customer, get_option( 'bookly_mailchimp_default_status' ) );
            $mailchimp->addMember( $member, get_option( 'bookly_mailchimp_audience_id' ) );
        }
    }

    /**
     * @inheritDoc
     */
    public static function postDeleteCustomer( Lib\Entities\Customer $customer )
    {
        if ( get_option( 'bookly_mailchimp_delete_customer_cascade' )
            && get_option( 'bookly_mailchimp_api_key' ) != ''
            && get_option( 'bookly_mailchimp_server' ) != ''
            && get_option( 'bookly_mailchimp_audience_id' ) != ''
        ) {
            $mailchimp = new ApiClient( get_option( 'bookly_mailchimp_api_key' ), get_option( 'bookly_mailchimp_server' ) );
            $member = new Member( $customer, get_option( 'bookly_mailchimp_default_status' ) );
            $mailchimp->deleteMember( $member, get_option( 'bookly_mailchimp_audience_id' ) );
        }
    }
}