<?php
namespace BooklyMailchimp\Lib\Mailchimp;

class ApiClient
{
    /** @var string */
    protected $api_key;
    /** @var string */
    protected $server;
    /** @var array */
    protected $response;
    /** @var array */
    protected $errors = array();

    /**
     * ApiClient constructor.
     *
     * @param string $api_key
     * @param string $server
     */
    public function __construct( $api_key, $server )
    {
        $this->api_key = $api_key;
        $this->server  = $server;
    }

    /**
     * @param Member $member
     * @param string $audience_id
     * @return bool|array
     */
    public function addMember( Member $member, $audience_id )
    {
        if ( $this->apiRequest( 'PUT', 'lists/' . $audience_id . '/members/' . $member->getMemberId(), $member->toJson() ) ) {
            return $this->getBody();
        }

        return false;
    }

    /**
     * @param Member $member
     * @param string $audience_id
     * @return bool|array
     */
    public function deleteMember( Member $member, $audience_id )
    {
        if ( $this->apiRequest( 'DELETE', 'lists/' . $audience_id . '/members/' . $member->getMemberId(), array() ) ) {
            return $this->getBody();
        }

        return false;
    }

    /**
     * Send HTTP request
     *
     * @param string $method
     * @param string $url_path
     * @param array|string $data
     * @return bool
     */
    private function apiRequest( $method, $url_path, $data )
    {
        $url = 'https://' . $this->server . '.api.mailchimp.com/3.0/' . $url_path;
        $args = array(
            'method' => $method,
            'sslverify' => false,
            'timeout' => 5,
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic ' . base64_encode( 'user:' . $this->api_key ),
            )
        );

        if ( $method === 'GET' ) {
            // WP 4.4.11 doesn't take into account the $data for the GET request
            // Manually move data in query string
            $query_data = array();
            foreach ( $data as $key => $value ) {
                $query_data[ $key ] = urlencode( $value );
            }
            $url = add_query_arg( $query_data, $url );
        } else {
            $args['body'] = $data;
        }

        $response = wp_remote_request( $url, $args );
        if ( $response instanceof \WP_Error ) {
            $this->errors[] = $response->get_error_messages();

            return false;
        }

        $this->response = json_decode( $response['body'], true );

        return ( $response['response']['code'] >= 200 && $response['response']['code'] <= 299 );
    }

    /**
     * @return array
     */
    private function getBody()
    {
        return $this->response;
    }
}