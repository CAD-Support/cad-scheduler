<?php
namespace BooklyMailchimp\Lib\Mailchimp;

use Bookly\Lib\Entities\Customer;

class Member
{
    /** @var string */
    protected $status_if_new;

    /** @var Customer */
    protected $customer;

    /**
     * Member constructor.
     *
     * @param Customer $customer
     * @param string   $status_if_new
     */
    public function __construct( Customer $customer, $status_if_new )
    {
        $this->customer = $customer;
        $this->status_if_new = $status_if_new;
    }

    /**
     * @return string
     */
    public function getMemberId()
    {
        return md5( strtolower( $this->customer->getEmail() ) );
    }

    /**
     * @return string
     */
    public function toJson()
    {
        $replace = array(
            '{client_email}' => $this->customer->getEmail(),
            '{client_first_name}' => $this->customer->getFirstName(),
            '{client_last_name}' => $this->customer->getLastName(),
            '{client_name}' => $this->customer->getFullName(),
            '{client_phone}' => $this->customer->getPhone(),
            '{client_address}' => $this->customer->getAddress(),
            '{client_birthday}' => $this->customer->getBirthday() ?: '',
            '{client_note}' => $this->customer->getNotes(),
        );
        $merge_fields = get_option( 'bookly_mailchimp_fields' ) ?: array();
        foreach ( $merge_fields as &$value ) {
            $value = strtr( $value, $replace );
        }

        $data = array(
            'email_address' => $this->customer->getEmail(),
            'status_if_new' => $this->status_if_new,
            'merge_fields' => $merge_fields,
        );

        return json_encode( $data );
    }

}