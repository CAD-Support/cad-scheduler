<?php
namespace BooklyCustomDuration\Backend\Modules\Appearance\ProxyProviders;

use Bookly\Backend\Modules\Appearance\Proxy;
use BooklyCustomDuration\Lib;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function renderServiceStepSettings()
    {
        self::renderTemplate( 'appearance_settings' );
    }
}