<?php
namespace BooklyCustomDuration\Backend\Components\Divi\ProxyProviders;

use Bookly\Backend\Components\Divi\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormFields( array $fields )
    {
        $fields['hide_service_duration'] = array(
            'label' => __( 'Hide duration', 'bookly' ),
            'type' => 'yes_no_button',
            'options' => array(
                'off' => esc_html__( 'No', 'bookly' ),
                'on' => esc_html__( 'Yes', 'bookly' ),
            ),
            'default' => 'off',
            'toggle_slug' => 'main_content',
        );

        return $fields;
    }

    /**
     * @inheritDoc
     */
    public static function prepareBooklyFormShortcode( array $shortcode, array $props )
    {
        list( $short_code, $hide ) = $shortcode;

        if ( isset( $props['hide_service_duration'] ) && $props['hide_service_duration'] === 'on' ) {
            $hide[] = 'service_duration';
        }

        return array( $short_code, $hide );
    }
}
